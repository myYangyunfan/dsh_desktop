/**
 * Host desktop availability, file associations, and open/reveal actions over the Session Remote.
 * The desktop answer is read once per page; a failed read renders no control.
 */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { RemoteResult } from '@deepseek-ai/dsh-api-remotes/client';
import type { SessionOpenWorkspacePathRequest, SessionWorkspacePathApplication } from '@deepseek-ai/dsh-api-session-controller/types';
import type { OpenInAppOutcome } from './outcome.ts';
/** What a path gesture asks of the Host desktop: the default application, or the file manager showing the file. */
export type OpenInAppPathAction = 'open' | 'reveal';
/** The slice of the Client Remote the path actions call. */
export interface OpenInAppPathRemote {
    readonly session: {
        /** Whether the Host can hand a workspace path to a native desktop. */
        canOpenWorkspacePath(): Promise<RemoteResult<boolean>>;
        /** Current registered file handlers and their default selection. */
        workspacePathApplications(request: {
            path: string;
        }, signal?: AbortSignal): Promise<RemoteResult<readonly SessionWorkspacePathApplication[]>>;
        /** Open one Host path in its default application, or reveal it in the file manager. */
        openWorkspacePath(request: SessionOpenWorkspacePathRequest, signal?: AbortSignal): Promise<RemoteResult<unknown>>;
    };
}
/** Page-lifetime desktop availability and the open/reveal carrier shared by every path control. */
export declare class OpenInAppPathController {
    private readonly remote;
    /** Whether the Host desktop can open paths; null until the Host answered, false also after a failed read. */
    readonly desktop: SnapshotStore<boolean | null>;
    private loading;
    /**
     * @param remote - the Session Remote namespace answering availability and running gestures.
     */
    constructor(remote: OpenInAppPathRemote);
    /**
     * Read desktop availability once per controller life; concurrent calls share the read.
     * @returns after availability is published.
     */
    load(): Promise<void>;
    /**
     * Open one Host path in its default application, or reveal it in the file manager.
     * @param path - absolute path on the Host, as the file's metadata reports it.
     * @param action - default application open, or file-manager reveal.
     * @param application - registered application path for an explicit open.
     * @returns the acknowledged open or reveal, or the named failure to announce.
     */
    openPath(path: string, action: OpenInAppPathAction, application?: string): Promise<OpenInAppOutcome>;
    /**
     * Refresh the file's OS associations; failures remain distinct from an empty handler list.
     * @param path - file path reported by the Host.
     * @param signal - lifetime of the requesting preview.
     * @returns application metadata, or null when the query fails.
     */
    applications(path: string, signal: AbortSignal): Promise<readonly SessionWorkspacePathApplication[] | null>;
    private run;
}
//# sourceMappingURL=open-path.d.ts.map