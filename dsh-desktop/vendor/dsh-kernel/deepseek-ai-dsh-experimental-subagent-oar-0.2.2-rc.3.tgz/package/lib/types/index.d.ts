/**
 * Named one-shot subagent providers backed by OAR's default runtime registry.
 * OAR owns native processes; installation checks occur on delegation.
 *
 * @module @deepseek-ai/dsh-experimental-subagent-oar
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "experimental-subagent-oar";
export declare const inject: string[];
/** Native runtime selection and deployment settings for one provider instance. */
export interface Config {
    /** OAR default-runtime id; unknown ids fail during plugin activation. */
    runtime: string;
    /** Name registered on ctx.subagents (default oar). */
    providerName?: string;
    /** Native model id; omission preserves the runtime's model selection. */
    model?: string;
    /** Native reasoning effort; unsupported choices fail during startup. */
    effort?: string;
    /** Explicit entries applied after ambient credential scrubbing; null removes a value. */
    env?: Record<string, string | null>;
    /** Native launch arguments, including permission settings; omission uses OAR defaults. */
    launchArgs?: string[];
    /** Optional turn deadline in milliseconds after startup; omission uses parent cancellation only. */
    timeoutMs?: number;
}
export declare const Config: z<Config>;
/**
 * Register one provider using a runtime in OAR's default registry.
 * @param ctx - context carrying the shared subagent service.
 * @param config - runtime, registry name, native settings, and turn deadline.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map