/** Multi-file patch tool over the guarded patch executor. */
import type { Context } from '@deepseek-ai/cordis';
import type { FsSandboxController } from './sandbox.ts';
/**
 * Register the patch tool and scope-aware guidance using the shared mutation controller.
 * @param ctx - plugin effect scope and filesystem services.
 * @param sandbox - per-call policy resolver and denial mapper.
 */
export declare function applyApplyPatchTool(ctx: Context, sandbox: FsSandboxController): void;
//# sourceMappingURL=apply-patch.d.ts.map