#!/usr/bin/env node
import type { RunCliOptions } from './bin.ts';
/**
 * Run the CLI in the importing carrier's module tree.
 * @param options - Installation-owned runtime options.
 * @returns Settlement of the selected command.
 */
export declare function runCli(options?: RunCliOptions): Promise<void>;
//# sourceMappingURL=installed-bin.d.ts.map