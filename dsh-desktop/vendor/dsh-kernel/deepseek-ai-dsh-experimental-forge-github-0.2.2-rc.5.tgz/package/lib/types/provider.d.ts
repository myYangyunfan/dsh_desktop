/** GitHub implementation of the forge provider contract. */
import type { BranchUpdateRequest, ChangeRequestKey, ChangeRequestRef, ChangeRequestSnapshot, ForgeActionFailure, ForgeCommitList, ForgeFailure, ForgeProvider, ForgeReadiness, ForgeRepository, ForgeRerunRequest, ForgeReviewData, ForgeReviewerCandidate, ForgeReviewersRequest, ForgeReviewRequest, ForgeReviewResult, ForgeReviewWrite, ForgeReviewWriteResult, ForgeViewedFiles, ForgeViewedRequest, MergeRequest } from '@deepseek-ai/dsh-experimental-forge';
import type { GhRunner } from './gh.ts';
/** Bounds on what one read retains or counts. */
export interface GitHubLimits {
    /** Maximum combined JSON bytes retained by an explicit check read or a review read. */
    readonly maxOutputBytes: number;
    /** Most review threads counted per pull request in one status read, and read in one review read. */
    readonly maxReviewThreads: number;
    /** Most commits one commit listing returns. */
    readonly maxCommits: number;
    /** Most files whose viewed marks one read lists. */
    readonly maxViewedFiles: number;
}
/** Reads GitHub and GitHub Enterprise pull requests through a `gh` runner. */
export declare class GitHubProvider implements ForgeProvider {
    private readonly gh;
    private readonly limits;
    readonly forge = "github";
    private readonly hosts;
    submitReview(ref: ChangeRequestRef, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Read the review threads of a pull request at `headSha` through GraphQL, each page naming the head it was read at.
     * @see readReviewThreads
     */
    readReview(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeReviewData | ForgeFailure>;
    /**
     * Write to the review threads or the pending review of a pull request through GraphQL mutations after a check of its head.
     * @see writeGitHubReview
     */
    writeReview(ref: ChangeRequestRef, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
    /**
     * @param gh - runner that executes `gh` on the host.
     * @param hosts - host names this provider serves, such as `github.com` and Enterprise hosts.
     * @param limits - bounds on retained check and review bytes, counted and read review threads, listed commits, and listed
     * viewed files.
     */
    constructor(gh: GhRunner, hosts: readonly string[], limits: GitHubLimits);
    repositoryFromRemote(url: string): ForgeRepository | undefined;
    changeRequestFromUrl(url: string): ChangeRequestRef | undefined;
    changeRequestUrl(ref: ChangeRequestRef): string;
    fetch(refs: readonly ChangeRequestRef[], signal: AbortSignal): Promise<ReadonlyMap<ChangeRequestKey, ChangeRequestSnapshot | ForgeFailure>>;
    fetchChecks(ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestSnapshot | ForgeFailure>;
    findByHead(repository: ForgeRepository, branch: string, signal: AbortSignal): Promise<readonly ChangeRequestRef[]>;
    /**
     * Mark a draft pull request ready for review with `gh pr ready`; one that
     * is already ready stays ready.
     */
    markReady(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Merge a pull request through the REST merge endpoint with the expected
     * head commit, so GitHub refuses with 409 once new commits arrived. Unlike
     * `gh pr merge`, it never enables auto-merge, never joins a merge queue, and
     * never deletes the head branch.
     */
    merge(ref: ChangeRequestRef, request: MergeRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Read the pull request's diff at `headSha`. One GraphQL read names the
     * current head and the base commit GitHub recorded with it; a head other
     * than `headSha` returns `stale`. Otherwise the compare endpoint reads the
     * patch from the merge base of that base commit and `headSha`, as the pull
     * request's own diff does, with both ends fixed. Given the `base` the latest
     * status recorded with `headSha`, the comparison from it runs while the
     * GraphQL read confirms the head; a stale head or another base commit
     * cancels that comparison and waits for it to end before the read returns.
     */
    diff(ref: ChangeRequestRef, headSha: string, signal: AbortSignal, base?: string): Promise<string | ForgeFailure>;
    /** Read one file at a commit through the contents API in its raw form. */
    fileText(ref: ChangeRequestRef, commit: string, path: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /** List the pull request's commits through GraphQL, at most `maxCommits`, all read at one head. */
    commits(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeCommitList | ForgeFailure>;
    /** Read the changes between two commits through the compare API in its diff form. */
    compare(ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /** Read the viewer's viewed marks through GraphQL, at most `maxViewedFiles`, every page at `headSha`. */
    viewedFiles(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeViewedFiles | ForgeFailure>;
    /** Set or clear the viewer's mark with `markFileAsViewed` or `unmarkFileAsViewed` after confirming the head. */
    setViewed(ref: ChangeRequestRef, request: ForgeViewedRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Rerun every finished workflow run with a failed GitHub Actions job on the head commit through the REST API; GitHub
     * reruns its failed jobs with the jobs that depend on them. A run with a check still pending waits, as GitHub offers
     * no rerun of a run in progress. Every eligible run is tried, and a refusal of one is reported with the others' outcome.
     * Other checks name no rerun.
     */
    rerunChecks(ref: ChangeRequestRef, request: ForgeRerunRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    requestReviews(ref: ChangeRequestRef, request: ForgeReviewersRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    reviewerCandidates(ref: ChangeRequestRef, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[] | ForgeFailure>;
    updateBranch(ref: ChangeRequestRef, request: BranchUpdateRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    fileUrl(ref: ChangeRequestRef, commit: string, path: string): string;
    readiness(host: string, signal: AbortSignal): Promise<ForgeReadiness>;
    /**
     * Run one reading `gh` command, returning its output. A refusal, a `gh` that
     * cannot start, output over `maxOutputBytes`, and a run past `timeoutMs` become failures.
     */
    private read;
    /** Run one GraphQL request; a refusal, a body that is not GraphQL, and GraphQL errors become failures. */
    private readonly graphql;
    /**
     * Run one GraphQL mutation through {@link sendMutation}, which never retries it: a refusal or a `gh` that cannot
     * start is `failed`, and an answer that does not confirm the outcome is `unknown`.
     */
    private readonly mutate;
    /** Run one changing `gh` command; a refusal or a `gh` that cannot start becomes a failure. */
    private act;
    /** Run one `gh` command; a `gh` that cannot start resolves to its error, and every other rejection passes on. */
    private attempt;
    private hostFailure;
    private fetchHost;
    /**
     * Run one continuation query of a snapshot read.
     * @param host - host the snapshot was read from.
     * @param variables - `gh api graphql` field flags, the query first.
     * @param signal - cancellation of the snapshot read.
     * @returns the output, or the failure of a `gh` that cannot start, times out, or prints over its limit.
     * @throws with `signal.reason` when the read is cancelled.
     */
    private continuation;
}
//# sourceMappingURL=provider.d.ts.map