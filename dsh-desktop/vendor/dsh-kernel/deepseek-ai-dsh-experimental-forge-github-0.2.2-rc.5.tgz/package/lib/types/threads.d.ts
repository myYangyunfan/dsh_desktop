/** Reads the review threads of a GitHub pull request at one head commit through GraphQL. */
import type { ChangeRequestRef, ForgeFailure, ForgeReviewData } from '@deepseek-ai/dsh-experimental-forge';
import type { GraphqlReader } from './commits.ts';
/**
 * First thread page with the head, the viewer, whether the viewer may comment, and the viewer's pending review; variables
 * `owner` and `name` are strings, `number` and `first` integers.
 */
export declare const REVIEW_QUERY: string;
/** Following thread page with the head it was read at; variables `id` and `cursor` are strings, `first` an integer. */
export declare const REVIEW_THREADS_QUERY: string;
/** Following comment page of one thread; variables `id` and `cursor` are strings. */
export declare const THREAD_COMMENTS_QUERY = "query($id: ID!, $cursor: String!) {\n  node(id: $id) { ... on PullRequestReviewThread { comments(first: 100, after: $cursor) { pageInfo { hasNextPage endCursor } nodes { id state createdAt url body viewerCanUpdate viewerCanDelete author { __typename login avatarUrl(size: 48) } } } } }\n}";
/** Bounds of one review read. */
export interface ReviewLimits {
    /** Most threads read. */
    readonly maxReviewThreads: number;
    /**
     * Most JSON bytes of all pages together: a later page that would pass it ends the read as truncated, and a first
     * page whose output alone passes it fails the read as `too-large`.
     */
    readonly maxOutputBytes: number;
}
/**
 * Read the review threads of a pull request while its head is `headSha`. The first page also names the head; every
 * following thread page names the head again, so a head that moves during the read returns
 * `stale`, while a thread's comment pages do not. Threads are read up to `maxReviewThreads`, each with all of its
 * comments. A later page that would bring the pages read, measured as JSON, past `maxOutputBytes` is dropped with the
 * threads after it, and the result is marked truncated; `read` fails a first page whose output alone passes the limit.
 * @param read - runs one GraphQL request.
 * @param ref - pull request, with an owner and name already checked for inlining.
 * @param headSha - head commit the threads must be read at.
 * @param limits - thread and byte bounds.
 * @param signal - cancellation of the read.
 * @returns the threads, or why GitHub did not provide them at `headSha`.
 */
export declare function readReviewThreads(read: GraphqlReader, ref: ChangeRequestRef, headSha: string, limits: ReviewLimits, signal: AbortSignal): Promise<ForgeReviewData | ForgeFailure>;
//# sourceMappingURL=threads.d.ts.map