/**
 * MCP client bridge plugin: connects to an external MCP server and registers
 * its tools on `ctx.tools` under server-qualified public names
 * (`mcp__<serverName>__<rawName>`). Each plugin instance connects to one MCP
 * server; load multiple instances in `cordis.yml` for multiple servers.
 *
 * Namespace plugin (named exports, no default export). Lifecycle is
 * effect-scoped: disposal disconnects from the server, unregisters all tools,
 * and releases the `serverName` namespace reservation. HMR hot-swaps by
 * disposing the old instance and creating a new one; identical `serverName`
 * reproduces identical public tool names.
 *
 * @module @deepseek-ai/dsh-mcp-client
 */
import type { Context, Fiber } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { resolveReconnectPolicy } from './connection.ts';
import type { ReconnectConfig } from './connection.ts';
import type { McpConnectionStatusHandle } from './status.ts';
export { createMcpToolDefinition } from './tools.ts';
export type { McpResult, McpToolDefinitionOptions } from './tools.ts';
export type { ReconnectConfig, ResolvedReconnectPolicy } from './connection.ts';
export type { McpConnectionStatusHandle } from './status.ts';
export type * from './types.ts';
export { probeServer } from './probe.ts';
export { assertTemplateSyntax } from './templates.ts';
export type { McpProbeOptions } from './probe.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "mcp-client";
/** Services required by this plugin. */
export declare const inject: string[];
/** Valid `serverName`, kept below the public tool-name budget. */
export declare const SERVER_NAME_PATTERN: RegExp;
/**
 * Read an MCP instance's stable status handle. Reloading the same Fiber keeps
 * the handle; final disposal detaches observers and leaves its last state readable.
 * @param fiber - the plugin Fiber or the handle returned by `ctx.plugin()`.
 * @returns the status handle, or `undefined` before the instance registers one.
 */
export declare function connectionStatusOf(fiber: Fiber): McpConnectionStatusHandle | undefined;
/** Config for connecting to an MCP server via a spawned child process over stdio. */
export interface StdioConfig {
    /** Selects child-process stdio transport. */
    transport: 'stdio';
    /**
     * Stable local namespace for this server's model-facing tool names
     * (`mcp__<serverName>__<rawName>`). Must match `[A-Za-z0-9_-]{1,32}` and be
     * unique among live mcp-client instances in the same registration scope.
     */
    serverName: string;
    /** Executable used to start the server. */
    command: string;
    /** Arguments passed directly, without shell interpolation. */
    args: string[];
    /** Extra env vars merged on top of scrubbed ambient env. */
    env: Record<string, string>;
    /** Working directory for the child process. */
    cwd: string;
    /** Timeout per tool call or resource request in milliseconds. */
    toolCallTimeoutMs: number;
    /** Optional budget for one connection attempt plus its initial tool sync, in milliseconds. */
    startupTimeoutMs?: number;
    /** Budget for transport closure and local cleanup, in milliseconds (default 5000). */
    closeTimeoutMs: number;
    /** Resolve `${credential:…}` in transport strings at runtime and redact resolved values from diagnostics (default false). */
    expandTemplates: boolean;
    /** Fail plugin activation when the initial connection or tool synchronization fails. */
    failOnStartupError: boolean;
    /** Maximum UTF-8 bytes of attributed server instructions (default 32768). */
    maxInstructionBytes?: number;
    /** Automatic reconnect policy after a lost connection; omission uses the defaults. */
    reconnect?: ReconnectConfig;
}
/** Config for connecting to an MCP server over Streamable HTTP (SSE). */
export interface StreamableHttpConfig {
    /** Selects Streamable HTTP transport. */
    transport: 'streamable-http';
    /**
     * Stable local namespace for this server's model-facing tool names
     * (`mcp__<serverName>__<rawName>`). Must match `[A-Za-z0-9_-]{1,32}` and be
     * unique among live mcp-client instances in the same registration scope.
     */
    serverName: string;
    /** MCP endpoint URL. */
    url: string;
    /** Additional headers attached to MCP requests. */
    headers: Record<string, string>;
    /** Timeout per tool call or resource request in milliseconds. */
    toolCallTimeoutMs: number;
    /** Optional budget for one connection attempt plus its initial tool sync, in milliseconds. */
    startupTimeoutMs?: number;
    /** Budget for transport closure and local cleanup, in milliseconds (default 5000). */
    closeTimeoutMs: number;
    /** Resolve `${credential:…}` in transport strings at runtime and redact resolved values from diagnostics (default false). */
    expandTemplates: boolean;
    /** Fail plugin activation when the initial connection or tool synchronization fails. */
    failOnStartupError: boolean;
    /** Maximum UTF-8 bytes of attributed server instructions (default 32768). */
    maxInstructionBytes?: number;
    /** Automatic reconnect policy after a lost connection; omission uses the defaults. */
    reconnect?: ReconnectConfig;
}
/** Configuration for one stdio or Streamable HTTP MCP server. */
export type Config = StdioConfig | StreamableHttpConfig;
type StdioConfigInput = Omit<StdioConfig, 'args' | 'env' | 'cwd' | 'toolCallTimeoutMs' | 'startupTimeoutMs' | 'failOnStartupError' | 'closeTimeoutMs' | 'expandTemplates'> & Partial<Pick<StdioConfig, 'args' | 'env' | 'cwd' | 'toolCallTimeoutMs' | 'startupTimeoutMs' | 'failOnStartupError' | 'closeTimeoutMs' | 'expandTemplates'>>;
type StreamableHttpConfigInput = Omit<StreamableHttpConfig, 'headers' | 'toolCallTimeoutMs' | 'startupTimeoutMs' | 'failOnStartupError' | 'closeTimeoutMs' | 'expandTemplates'> & Partial<Pick<StreamableHttpConfig, 'headers' | 'toolCallTimeoutMs' | 'startupTimeoutMs' | 'failOnStartupError' | 'closeTimeoutMs' | 'expandTemplates'>>;
type ConfigInput = StdioConfigInput | StreamableHttpConfigInput;
/**
 * Reconnect-policy section schema, exported so a manager composing mcp-client
 * instances (`dsh-mcp-manager`) validates the same fields, defaults, and
 * bounds without restating them.
 */
export declare const ReconnectSchema: z<ReconnectConfig>;
export declare const Config: z<ConfigInput, Config>;
/**
 * Connect one MCP server and publish its initial tool generation before activation.
 * This entry remains explicitly `async`: Cordis treats a prototype-bearing
 * ordinary function as a constructor, whose returned Promise is not startup work.
 * @param ctx - plugin context carrying the tool registry.
 * @param config - resolved transport and server namespace configuration.
 * @returns startup readiness after connection and initial tool discovery settle.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map