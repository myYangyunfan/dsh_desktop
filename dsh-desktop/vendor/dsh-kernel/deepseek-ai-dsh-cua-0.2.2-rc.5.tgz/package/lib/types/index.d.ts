import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import { NativeClient, type NativeChannelFactory } from './native-client.ts';
import type { CuaApplicationGrant, CuaSystemPermission } from './access-types.ts';
import type { CuaStartupCapabilities } from './types.ts';
import type { ToolExecution } from '@deepseek-ai/dsh-tools';
export { CuaAccess } from './access.ts';
export type { CuaStartupCapabilities } from './types.ts';
/** Native executable and per-operation resource bounds. */
export interface CuaConfig {
    /** Ask once per live Session before an explicitly requested system-pointer move. */
    requireSystemPointerApproval: boolean;
    /** Register tools for Agents using this preset; defaults to ptc. False enables global registration. */
    agentPreset: string | false;
    /** Legacy grants imported once into profile-scoped storage; later edits are ignored. */
    allowedApps: Array<Omit<CuaApplicationGrant, 'id'> & {
        /** Unbranded digest at the profile configuration boundary; admitted by the Config schema. */
        id: string;
    }>;
    /** Absolute executable inside the signed macOS helper .app; omission prepares the package-owned application. */
    helperPath?: string;
    /** Maximum time in milliseconds for native component preparation. */
    buildTimeoutMs: number;
    /** Deadline for one native operation, including capture and AX traversal. */
    timeoutMs: number;
    /** Maximum time to connect to or start the shared native helper. */
    connectTimeoutMs: number;
    /** Screenshot deadline including time queued behind other native operations. */
    screenshotTimeoutMs: number;
    /** Deadline for each individual Accessibility system call. */
    axTimeoutMs: number;
    /** Maximum bytes retained for one helper response frame. */
    maxResponseBytes: number;
    /** Maximum installed application matches returned for one discovery query. */
    maxAppMatches: number;
    /** Maximum bytes preserved from the system clipboard during one paste. */
    maxClipboardBytes: number;
    /** Maximum wait for clipboard data consumption after the Paste command returns. */
    pasteReadTimeoutMs: number;
    /** Maximum UTF-8 bytes admitted for one helper request frame. */
    maxRequestBytes: number;
    /** Duration in milliseconds of one same-window drag. */
    dragDurationMs: number;
    /** Maximum explicitly requested mouse-button hold in milliseconds; zero allows immediate release only. */
    maxClickHoldMs: number;
    /** Number of movement segments dispatched during a drag. */
    dragSteps: number;
    /** Delay in milliseconds after each Unicode key-down or key-up event. */
    textEventIntervalMs: number;
    /** Native connection cleanup, socket-write and launcher termination budget in milliseconds. */
    graceMs: number;
    /** Default node limit when an accessibility read omits maxElements. */
    maxElements: number;
    /** Default depth limit when an accessibility read omits maxDepth. */
    maxDepth: number;
}
/** Validate shared configuration for native providers. */
export declare const CuaConfig: Schema<Schemastery.ObjectS<NoInfer<{
    requireSystemPointerApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    requireSystemPointerApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
}>>, "plain">;
/** Prepared platform executable, transport, platform-specific instructions and startup capabilities. */
export interface CuaBackend {
    helperPath: string;
    createChannel: NativeChannelFactory;
    guidance: string;
    capabilities: CuaStartupCapabilities;
    /** Dispatch a directional key through the provider's execution-scoped input owner, after application authorization. */
    sendKeyEvent?: (client: NativeClient, params: Record<string, JsonValue>, execution: Readonly<ToolExecution>) => Promise<JsonValue>;
    /**
     * Build native permission parameters for the selected action and Client language.
     * @param method Native permission action.
     * @param permission System privilege selected by the user.
     * @param locale Current Client language.
     * @returns Parameters accepted by the provider's native implementation.
     */
    permissionParameters: (method: 'requestPermission' | 'openPermissionSettings', permission: CuaSystemPermission, locale: string) => Record<string, JsonValue>;
}
/**
 * Install authorized CUA calls and Agent-owned native connections.
 * @param ctx - Provider context with computer-use, subprocess, tools, prompt, and Agent services.
 * @param config - Validated resource limits and live application grants.
 * @param backend - Platform-owned executable, connection factory, and instructions.
 */
export declare function installCua(ctx: Context, config: CuaConfig, backend: CuaBackend): void;
/** Host marker for the optional Client contribution; platform providers install native execution separately. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map