/**
 * Conversion of one exported DeepSeek conversation tree into the seed log of
 * one DSH Session.
 *
 * The message named by `current_message_id` selects the imported branch, with
 * the greatest message id as the fallback. Each USER message opens a turn; a
 * finished ASSISTANT reply becomes one or more steps whose web searches and
 * opened pages replay as `web_search` and `web_fetch` calls. A question whose
 * reply was withdrawn by content filtering is left out with its reply. Other
 * unfinished, templated, empty, or missing replies end their turn with an
 * error and never enter model history.
 */
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ExportMessage, ExportSessionFile } from './format.ts';
/** Provider and model recorded on every imported assistant message. */
export declare const IMPORTED_MODEL_SOURCE: {
    readonly provider: "deepseek-chat-export";
    readonly model: "deepseek-chat-export";
};
/** A conversation file that cannot be imported; the message names the defect. */
export declare class ExportConversationError extends Error {
    readonly name = "ExportConversationError";
}
/** Inputs that make conversion deterministic and pure. */
export interface ConvertConversationOptions {
    /** Mint one unique id for each message and tool call. */
    readonly createId: () => string;
    /** Largest UTF-8 size of the imported title; longer titles are truncated after whitespace is collapsed. */
    readonly maxTitleBytes: number;
    /** Saved images keyed by export file id; image files without an entry become synthetic file cards. */
    readonly images?: ReadonlyMap<string, ImageAttachmentRef>;
}
/** One converted conversation. */
export interface ConvertedConversation {
    /** Normalized original title, or null when it is absent or normalizes to empty. */
    readonly title: string | null;
    /** Epoch milliseconds of the first event, used as the Session creation time. */
    readonly createdAt: number;
    /** Seed events contiguous from seq 0, without a `session/end-seed` marker. */
    readonly events: readonly SessionEvent[];
}
/**
 * Select the imported branch of one conversation tree: the path from the root
 * to the message named by `current_message_id`, or to the message with the
 * greatest id when that field is absent, null, or names no message. A child
 * always has a greater id than its parent, so the fallback is a leaf.
 * @param file - one validated conversation file.
 * @returns messages from root to the selected message.
 * @throws {ExportConversationError} for an empty tree, duplicate ids, a missing parent, or a cycle.
 */
export declare function selectBranch(file: ExportSessionFile): readonly ExportMessage[];
/**
 * Read the time of a message as epoch milliseconds.
 * @param message - one export message.
 * @returns the parsed `inserted_at`.
 * @throws {ExportConversationError} when the timestamp is invalid.
 */
export declare function messageTime(message: ExportMessage): number;
/**
 * Convert one conversation into the seed log of a DSH Session.
 * @param file - one validated conversation file.
 * @param options - id source and saved images.
 * @returns the title, creation time, and seed events.
 * @throws {ExportConversationError} when the tree, a timestamp, or a mapped fragment is invalid, or no turn remains.
 */
export declare function convertConversation(file: ExportSessionFile, options: ConvertConversationOptions): ConvertedConversation;
//# sourceMappingURL=conversation.d.ts.map