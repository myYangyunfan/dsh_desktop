/** Remote contribution mounting and the `sidebar.session.action` layer. */
import type { Context } from '@deepseek-ai/cordis';
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
/** Services the browser half reads. */
export declare const inject: string[];
/**
 * Mount the generated Remote contribution, then the UI that calls it.
 * @param ctx - browser plugin context.
 * @param contribution - generated `deepseekChatImport` Remote definitions.
 * @returns disposer withdrawing the UI before the Remote namespace.
 */
export declare function mountImport(ctx: Context, contribution: TypertRemoteContribution): Promise<() => Promise<void>>;
//# sourceMappingURL=mount.d.ts.map