import type { DeepseekChatImportResponse } from '../types.ts';
/** Progress of one upload: bytes still sending, the Host reading the archive, then Sessions written. */
export type UploadProgress = {
    readonly phase: 'uploading';
    readonly fraction: number;
} | {
    readonly phase: 'reading';
} | {
    readonly phase: 'importing';
    readonly done: number;
    readonly total: number;
};
/** The Host outcome, or a transport failure before an outcome line arrived. */
export type UploadAnswer = DeepseekChatImportResponse | {
    readonly ok: false;
    readonly transport: string;
};
/**
 * Send one archive and follow the streamed answer to its outcome line.
 * A page whose Host runs in another execution context supplies the pre-boot
 * `__DSH_TRANSPORT__.fetch` carrier, which carries the body and the streamed
 * answer over its own channel; that carrier reports no byte progress. Served
 * pages send the archive with XMLHttpRequest, so the browser streams it from
 * disk and reports upload progress.
 * @param file - archive chosen in the browser.
 * @param workspaceId - Workspace receiving the Sessions.
 * @param onProgress - upload progress, the reading phase, then Sessions written.
 * @param signal - aborts the request; Sessions already written stay.
 * @returns the decoded Host outcome or the transport failure.
 */
export declare function uploadArchive(file: Blob, workspaceId: string, onProgress: (progress: UploadProgress) => void, signal: AbortSignal): Promise<UploadAnswer>;
//# sourceMappingURL=upload.d.ts.map