/**
 * Patterns of `.gitattributes` lines, matched as Git's wildmatch matches them: `*` and `?` stay within one path
 * segment, `**` between slashes or at either end crosses segments, `[...]` sets take `!` or `^` for negation, ranges,
 * and POSIX classes, `\` makes the next character literal, and every other character, including `(`, `{`, and `+`,
 * is literal. Matching is case-sensitive, as in Git unless `core.ignoreCase` is set, and compares characters where Git
 * compares UTF-8 bytes, so `?` and ranges differ from Git only for characters outside ASCII.
 */
/**
 * Compile one `.gitattributes` pattern, without the leading `/` that anchors it, into a test of a path.
 * @param pattern - the pattern as written, which the caller has checked is not quoted, negated, or a directory.
 * @returns a test of the text the pattern applies to, or undefined for a pattern that can match nothing.
 */
export declare function wildmatch(pattern: string): ((text: string) => boolean) | undefined;
//# sourceMappingURL=wildmatch.d.ts.map