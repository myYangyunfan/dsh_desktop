/**
 * Review layers of changed files. A repository's root `.gitattributes` decides first: its `dsh-review-layer`
 * attribute names a layer, and `linguist-generated` places a file in the `test` layer. The panel's `testPaths` and
 * `interfacePaths` configuration comes next, then the built-in rules, which follow the default file and directory
 * conventions of common languages and tools; every other file is in the `implementation` layer.
 */
import type { ParsedDiffFile } from './diff.ts';
import type { ForgeDiffFile, ForgeFileLayer } from './types.ts';
/** Path of the attributes file read beside each diff, relative to the repository root. */
export declare const ATTRIBUTES_PATH = ".gitattributes";
/** The attribute a repository sets to a layer name to place files in that layer. */
export declare const LAYER_ATTRIBUTE = "dsh-review-layer";
/**
 * Tests, test data, snapshots, locale dictionaries, and lockfiles by the default conventions of their tools: test
 * directories, Jest and Vitest `*.spec.*` and `*.test.*` files, `go test` `*_test.go` files and `testdata/`
 * directories, pytest's `test_*.py`, `*_test.py`, and `conftest.py`, RSpec's `spec/` and `*_spec.rb`, SwiftPM's
 * `Tests/`, .NET `*.Tests/` projects, Jest and insta snapshots, i18next and Rails `locales/`, gettext catalogs,
 * Apple `.lproj` strings, Android string resources, and the lockfiles of npm, pnpm, Yarn, Bun, Cargo, Go modules,
 * Poetry, uv, Pipenv, Bundler, Composer, SwiftPM, NuGet, Gradle, pub, Mix, and Nix flakes.
 */
export declare const BUILT_IN_TEST_PATHS: readonly string[];
/**
 * Package manifests of npm, Go modules, Cargo, Python packaging, Bundler and RubyGems, Maven, Gradle, MSBuild,
 * SwiftPM, Composer, pub, and Mix; TypeScript declarations, Python stubs, and C and C++ headers; and interface
 * definitions of Protocol Buffers, GraphQL, Thrift, and OpenAPI.
 */
export declare const BUILT_IN_INTERFACE_PATHS: readonly string[];
/** What a repository's attributes say about one path. */
interface PathAttributes {
    /** The layer `dsh-review-layer` names, or undefined while it is unspecified. */
    readonly layer: ForgeFileLayer | undefined;
    /** Whether `linguist-generated` is set. */
    readonly generated: boolean;
}
/**
 * Read the review attributes a `.gitattributes` text gives each path. Lines apply in order, so a later line overrides
 * an earlier one. `dsh-review-layer=<layer>` names `test`, `interface`, or `implementation`; another value,
 * `-dsh-review-layer`, and `!dsh-review-layer` leave the layer unspecified. `linguist-generated` and `=true` set
 * the generated attribute, `-linguist-generated` and `=false` unset it, and `!linguist-generated` returns it to
 * unspecified. Patterns follow Git's wildmatch rules, as {@link wildmatch} describes: a pattern without `/` matches a
 * file name at any depth, and one with `/` matches the path from the repository root. Macro definitions, quoted
 * patterns, negated patterns, which Git ignores in attributes, and patterns ending in `/`, which name directories and
 * so never match a file, are skipped.
 * @param attributes - the text of the root `.gitattributes`, empty without one.
 * @returns the attributes of a repository-relative path.
 */
export declare function attributesOf(attributes: string): (path: string) => PathAttributes;
/** Classifies changed files into review layers by a repository's attributes, the panel's globs, and the built-in rules. */
export declare class FileLayers {
    private readonly rules;
    /**
     * @param testPaths - configured globs of the `test` layer, checked before the built-in rules.
     * @param interfacePaths - configured globs of the `interface` layer, checked after `testPaths` and before the built-in rules.
     */
    constructor(testPaths: readonly string[], interfacePaths: readonly string[]);
    /**
     * Place each file in its layer: the layer its attributes name, else `test` for a generated file, else the first
     * configured or built-in rule its path matches, else `implementation`.
     * @param files - parsed files.
     * @param attributes - the text of the repository's root `.gitattributes`, empty without one.
     * @returns the files in the same order with their layers.
     */
    classify(files: readonly ParsedDiffFile[], attributes: string): ForgeDiffFile[];
}
export {};
//# sourceMappingURL=layers.d.ts.map