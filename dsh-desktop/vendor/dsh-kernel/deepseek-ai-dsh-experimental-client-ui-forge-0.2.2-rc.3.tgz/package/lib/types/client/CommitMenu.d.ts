/**
 * Commit picker of the changes header: every commit, or one commit, or with Shift a run of consecutive commits of a
 * change request or of the local `branch` scope, listed oldest first like the code host's commit list. A run is
 * accepted only when each of its commits has the one listed before it as its first parent.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeCommitList } from '@deepseek-ai/dsh-experimental-forge/types';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeCommitRange, ForgeLocalCommits } from '../types.ts';
import type { NS } from './locales.ts';
/** Props of the commit picker. */
export interface CommitMenuProps extends PropsLocale<typeof NS> {
    /** Commits shown, or null for all of them. */
    readonly chosen: ForgeCommitRange | null;
    /** Whether the owning tab is visible; a hidden tab keeps the menu closed. */
    readonly visible: boolean;
    /** Read the commits; null means the source cannot show single commits. `signal` aborts the read. */
    readonly list: (signal: AbortSignal) => Promise<RemoteResult<ForgeCommitList | ForgeLocalCommits | null>>;
    /** Which commits a truncated list keeps: a change request lists its oldest ones, the local branch its newest ones. */
    readonly kept: 'oldest' | 'newest';
    /** Changes when the commits may have changed, such as a new head commit or a refresh; the commits are read once per value. */
    readonly version: string;
    /** Show consecutive commits, or every commit for null. */
    readonly choose: (commits: ForgeCommitRange | null) => void;
}
/**
 * Name the shown commits on the trigger.
 * @param chosen - the shown commits, or null for all of them.
 * @param t - forge panel copy.
 * @returns the label.
 */
export declare function commitsLabel(chosen: ForgeCommitRange | null, t: PropsLocale<typeof NS>['t']): string;
/**
 * Render the trigger and, while open, the commit list. A click shows one commit; a Shift click shows the commits
 * from the last commit clicked without Shift to the clicked one.
 * @param props - the shown commits, the listing read, the choose action, and copy.
 * @returns the trigger with its portalled menu, or nothing when the source cannot show single commits.
 */
export declare function CommitMenu({ chosen, visible, list, kept, version, choose, t }: CommitMenuProps): ReactNode;
//# sourceMappingURL=CommitMenu.d.ts.map