/**
 * Body of the changes tab: the local changes of the Session's checkout in a
 * chosen scope, or the changes of one of its change requests, as one list of
 * file sections under a toolbar that jumps between files and switches the
 * layout. The view reads the changes when it opens, on each navigation, on
 * refresh, and when the change request's head or the checkout's `branch`
 * scope summary changes; a read keeps the previous changes on screen until it settles.
 * File sections receive values that keep their identity across renders, so a
 * render of the view redraws only the sections whose own values changed, and
 * an expanded file draws its lines once its section comes near the scrollport.
 */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { SidebarRightTabInfo } from '@deepseek-ai/dsh-client-ui-sidebar-right/client';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeBaseBranches, ForgeChangeRequestDiff, ForgeCommitRange, ForgeLocalCommits, ForgeLocalDiff, ForgeLocalScope } from '../types.ts';
import type { ForgeCommitList, ForgeReviewData, ForgeReviewRequest, ForgeReviewResult, ForgeReviewThread, ForgeReviewWrite, ForgeReviewWriteResult, ForgeViewedFiles, ForgeViewedRequest } from '@deepseek-ai/dsh-experimental-forge/types';
import { type ReviewQueue } from './review-queue.ts';
import type { ReviewSelection } from './review.ts';
import type { createChangesStore } from './changes-store.ts';
import { type ViewedFiles } from './viewed-files.ts';
import type { ForgePanelKey, NS } from './locales.ts';
import type { PanelSnapshot } from './source.ts';
/** Business face of the changes tab body. */
export interface ChangesTabInjected {
    /** Append a frozen comment to the main input without submitting it. */
    readonly addReviewToInput: (selection: ReviewSelection) => boolean;
    /** Records retained across Session switches and cleared when this tab occurrence closes. */
    readonly reviewQueue: (tab: Pick<SidebarRightTabInfo['tab'], 'id' | 'signal'>) => ReviewQueue;
    /** Publish one comment or a completed review; never retries mutations. */
    readonly submitReview: (url: string, request: ForgeReviewRequest) => Promise<RemoteResult<ForgeReviewResult>>;
    /** Panel source while visible; the renderer releases the subscription for an inactive key. */
    readonly keyedHooks: {
        readonly panel: (visibility: string) => HostObservable<PanelSnapshot> | undefined;
    };
    /** Open the panel stream again after it ended. */
    readonly reconnect: () => void;
    /** Read the local changes of one scope; `signal` aborts the read. */
    readonly localDiff: (scope: ForgeLocalScope, signal: AbortSignal) => Promise<RemoteResult<ForgeLocalDiff>>;
    /** Read the branches the `branch` scope can compare with, whose names contain `query`; `signal` aborts the read. */
    readonly diffBases: (query: string, signal: AbortSignal) => Promise<RemoteResult<ForgeBaseBranches>>;
    /** Read the new side of one file in a local scope. */
    readonly localText: (scope: ForgeLocalScope, path: string) => Promise<RemoteResult<string>>;
    /** List the commits of the `branch` scope compared with `base`, or with the automatic fork point for null; `signal` aborts the read. */
    readonly localCommits: (base: string | null, signal: AbortSignal) => Promise<RemoteResult<ForgeLocalCommits>>;
    /** Read the changes of a change request, or of consecutive commits of it, by its binding URL; `signal` aborts the read. */
    readonly changeRequestDiff: (url: string, commits: ForgeCommitRange | null, signal: AbortSignal) => Promise<RemoteResult<ForgeChangeRequestDiff>>;
    /** List the commits of a change request, or null when its provider does not read commits; `signal` aborts the read. */
    readonly changeRequestCommits: (url: string, signal: AbortSignal) => Promise<RemoteResult<ForgeCommitList | null>>;
    /** The Session's viewed marks, kept in the browser for local changes, chosen commits, and hosts that keep none. */
    readonly viewedFiles: ViewedFiles;
    /**
     * Read the signed-in user's viewed marks on a change request's files at `headSha`, or null when its provider keeps
     * none; `signal` aborts the read.
     */
    readonly changeRequestViewed: (url: string, headSha: string, signal: AbortSignal) => Promise<RemoteResult<ForgeViewedFiles | null>>;
    /** Set or clear the signed-in user's viewed mark on one file of a change request. */
    readonly setFileViewed: (url: string, request: ForgeViewedRequest) => Promise<RemoteResult<void>>;
    /** Read one file of a change request at a commit. */
    readonly changeRequestText: (url: string, commit: string, path: string) => Promise<RemoteResult<string>>;
    /** Read the review threads of a change request at the head of its latest status; `signal` aborts the read. */
    readonly changeRequestReview: (url: string, headSha: string, fresh: boolean, signal: AbortSignal) => Promise<RemoteResult<ForgeReviewData>>;
    /** Write to the review threads or the pending review of a change request; never retries a write. */
    readonly changeRequestReviewWrite: (url: string, write: ForgeReviewWrite) => Promise<RemoteResult<ForgeReviewWriteResult>>;
    /** Quote a whole review thread of the change request at `url` in the main input without submitting it. */
    readonly addThreadToInput: (thread: ForgeReviewThread, url: string, range: string | null) => boolean;
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Copy a path to the clipboard and report the outcome. */
    readonly copyPath: (path: string) => void;
    /** Ask the Session's Agent to create a change request for its changes, reporting the outcome. */
    readonly createChangeRequest: () => void;
    /** Show a failure notice. */
    readonly report: (key: ForgePanelKey, params?: Readonly<Record<string, string>>) => void;
}
/** Full props of the changes tab body. */
export type ChangesTabProps = Pick<PropsRuntime<'sidebar.right.pane.tab'>, 'useTabInfo' | 'sessionId'> & PropsStore<ReturnType<typeof createChangesStore>> & InjectFace<ChangesTabInjected> & PropsLocale<typeof NS>;
/**
 * Render the changes tab of one Session.
 * @param props - tab information, the tab's choices, the panel snapshot hook, reads and actions, and copy.
 * @returns the view body.
 */
export declare function ChangesTab({ useTabInfo, sessionId, useStore, actions, usePanel, reconnect, localDiff, diffBases, localText, localCommits, changeRequestDiff, changeRequestText, changeRequestCommits, changeRequestReview, changeRequestReviewWrite, viewedFiles, changeRequestViewed, setFileViewed, openLink, copyPath, createChangeRequest, addReviewToInput, addThreadToInput, reviewQueue, submitReview, report, t, }: ChangesTabProps): ReactNode;
//# sourceMappingURL=ChangesTab.d.ts.map