/**
 * Review threads of a change request inside the changes view: a thread card at its lines or at the top of its file, a
 * resolved thread folded into one row, and the outdated threads of a file in a section after its lines. A card offers
 * the writes the signed-in user may make: a reply, published at once or added to the pending review, resolving or
 * unresolving the thread, and editing or deleting the user's own comments.
 */
import { type ReactNode } from 'react';
import { type MarkdownLabels } from '@deepseek-ai/dsh-client-ui-primitives';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeReviewComment, ForgeReviewThread, ForgeReviewWrite, ForgeThreadId } from '@deepseek-ai/dsh-experimental-forge/types';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import { type ThreadPlace } from './review-threads.ts';
import type { NS } from './locales.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** Each member of a union without its `headSha`. */
type WithoutHead<T> = T extends unknown ? Omit<T, 'headSha'> : never;
/** A write to one thread or its comments, without the head commit the changes view adds. */
export type ThreadWrite = WithoutHead<Extract<ForgeReviewWrite, {
    readonly kind: 'reply' | 'resolve' | 'edit-comment' | 'delete-comment';
}>>;
/** Writes the signed-in user can make to the threads of one changes view. */
export interface ThreadWrites {
    /** Send a write; resolves to the message to show, or undefined once the code host took it. */
    readonly write: (write: ThreadWrite) => Promise<string | undefined>;
    /** Whether the user has a pending review, which every reply then joins. */
    readonly reviewStarted: boolean;
    /** Whether the user can add a reply to a pending review, starting one when needed. */
    readonly canReview: boolean;
}
/** Reads, actions, and identities every thread card of one changes view shares. */
export interface ThreadActions {
    /** Login of the change request's author, or null when the host hides it. */
    readonly author: string | null;
    /** Quote the whole thread in the main input without sending it; false when the input refused it. */
    readonly addToInput: (thread: ForgeReviewThread, range: string | null) => boolean;
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Read a file of the change request's repository at a commit. */
    readonly readText: (commit: string, path: string) => Promise<RemoteResult<string>>;
    /** Report that the input refused a thread. */
    readonly inputFailed: () => void;
    /** The latest jump to a thread, which unfolds that thread and its section until the reader folds them again; null before any. */
    readonly focused: ThreadFocus | null;
    /** Writes the user can make, or null when the code host takes none from this view. */
    readonly writes: ThreadWrites | null;
}
/** One jump to a thread; each jump has its own revision, so a jump to the same thread unfolds it again. */
export interface ThreadFocus {
    readonly id: ForgeThreadId;
    readonly revision: number;
}
/** A host thread shown on lines of one side. */
export interface LineThread {
    readonly thread: ForgeReviewThread;
    readonly place: Extract<ThreadPlace, {
        readonly kind: 'line';
    }>;
}
/** Host threads of one file and the actions their cards share. */
export interface FileThreads {
    /** Threads on lines, which follow the row of their last line. */
    readonly lines: readonly LineThread[];
    /** Threads on the whole file, shown above its lines. */
    readonly file: readonly ForgeReviewThread[];
    /** Threads no longer on the head's lines, shown after them. */
    readonly outdated: readonly ForgeReviewThread[];
    /** Unresolved threads of the file in every place, including threads the chosen commits do not show. */
    readonly unresolved: number;
    /** Reads, actions, and identities shared by the cards. */
    readonly actions: ThreadActions;
}
/**
 * Build the Markdown chrome copy of comment bodies.
 * @param t - forge panel copy.
 * @returns labels for code fences and footnotes.
 */
export declare function useMarkdownLabels(t: Translate): MarkdownLabels;
/**
 * Render an author's avatar, or the first letter of the login when the image is missing or fails.
 * @param props - the comment's author and the avatar size.
 * @returns the round avatar.
 */
export declare function Avatar({ author, size }: {
    readonly author: ForgeReviewComment['author'];
    readonly size?: number;
}): ReactNode;
/**
 * Render one thread: its place, every comment, its reply field, and its actions. A resolved thread folds into one row
 * until the reader unfolds it or jumps to it.
 * @param props - the thread, where it shows, the shared actions, and copy.
 * @returns the thread card or its folded row.
 */
export declare function ThreadCard({ thread, place, actions, t }: PropsLocale<typeof NS> & {
    readonly thread: ForgeReviewThread;
    readonly place: ThreadPlace;
    readonly actions: ThreadActions;
}): ReactNode;
/**
 * Render the outdated threads of a file after its lines, as one section the reader can fold.
 * @param props - the threads, the shared actions, and copy.
 * @returns the section, or nothing without outdated threads.
 */
export declare function OutdatedThreads({ threads, actions, t }: PropsLocale<typeof NS> & {
    readonly threads: readonly ForgeReviewThread[];
    readonly actions: ThreadActions;
}): ReactNode;
export {};
//# sourceMappingURL=ReviewThreads.d.ts.map