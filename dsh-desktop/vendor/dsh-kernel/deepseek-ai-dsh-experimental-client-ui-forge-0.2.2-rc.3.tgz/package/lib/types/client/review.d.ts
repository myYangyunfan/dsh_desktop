/** Frozen line selections shared by the diff UI, composer references, and review submission. */
import type { QuoteSummary } from '@deepseek-ai/dsh-client-ui-primitives';
import type { ForgeCommitRange, ForgeDiffFile } from '../types.ts';
/** A comment on consecutive lines of one side of one displayed hunk. */
export interface ReviewComment {
    /** Repository-relative destination path, including for renamed files. */
    readonly path: string;
    /** Old or new side of the displayed diff. */
    readonly side: 'L' | 'R';
    /** First selected line, inclusive. */
    readonly startLine: number;
    /** Last selected line, inclusive. */
    readonly endLine: number;
    /** Complete displayed hunk captured before subsequent file changes. */
    readonly hunk: string;
    /** User's plain-text comment. */
    readonly body: string;
}
/**
 * The immutable source from which a comment was selected. `commits` names the consecutive commits shown instead of
 * the whole change request or `branch` scope, or is null for all of them.
 */
export type ReviewSource = 
/**
 * Local changes in a scope. `base` names what the `branch` scope compared with for the reader, and is null for
 * other scopes; `baseRef` identifies the comparison: the chosen ref, or null for the automatic fork point and other scopes.
 */
{
    readonly kind: 'local';
    readonly scope: string;
    readonly base: string | null;
    readonly baseRef: string | null;
    readonly commits: ForgeCommitRange | null;
}
/** A change request; `headSha` is the commit the shown changes end at: the head, or the last chosen commit. */
 | {
    readonly kind: 'change';
    readonly url: string;
    readonly headSha: string;
    readonly commits: ForgeCommitRange | null;
};
/** One selected range and the source the user saw. */
export interface ReviewSelection {
    readonly source: ReviewSource;
    readonly comment: ReviewComment;
}
/**
 * Capture a range only when both endpoints belong to the same displayed hunk.
 * @param file - loaded diff file.
 * @param side - selected side.
 * @param from - first gesture endpoint.
 * @param to - current gesture endpoint.
 * @returns a frozen selection, or undefined for unchanged gaps or cross-hunk ranges.
 */
export declare function selectReviewLines(file: ForgeDiffFile, side: 'L' | 'R', from: number, to: number): ReviewComment | undefined;
/**
 * Name a comment's side and lines, such as `R12` or `L3–5`.
 * @param comment - the commented range.
 * @returns the range label shown beside comments and in composer quotes.
 */
export declare function reviewRange(comment: ReviewComment): string;
/**
 * Describe a composer quote of a comment by its file, range, and text instead of the whole message reference.
 * @param comment - the quoted comment.
 * @returns the composer's display of the quote.
 */
export declare function reviewQuoteSummary(comment: ReviewComment): QuoteSummary;
/**
 * Format a frozen reference for the ordinary, logged user message.
 * @param selection - source, range, displayed patch, and user comment.
 * @param index - one-based reference number in the composer.
 * @returns Markdown content for an atomic composer quote.
 */
export declare function formatReviewComment(selection: ReviewSelection, index: number): string;
/**
 * Check whether the current diff still contains the captured range and hunk.
 * @param selection - saved comment source and patch.
 * @param source - currently displayed review source.
 * @param file - current diff file.
 * @returns whether an inline record can retain its original line placement.
 */
export declare function reviewMatches(selection: ReviewSelection, source: ReviewSource, file: ForgeDiffFile): boolean;
//# sourceMappingURL=review.d.ts.map