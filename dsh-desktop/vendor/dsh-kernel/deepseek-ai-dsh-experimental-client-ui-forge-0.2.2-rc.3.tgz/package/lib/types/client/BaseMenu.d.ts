/** Base branch picker of the local changes view's `branch` scope: the automatic fork point, then remote-tracking and local branches. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeBaseBranch, ForgeBaseBranches } from '../types.ts';
import type { NS } from './locales.ts';
/** Props of the base branch picker. */
export interface BaseMenuProps extends PropsLocale<typeof NS> {
    /** Chosen branch, or null for the automatic fork point. */
    readonly chosen: ForgeBaseBranch | null;
    /** Name the trigger shows: the chosen branch, the automatic fork point, or the automatic choice's own name. */
    readonly label: string;
    /** Whether the chosen branch no longer exists. */
    readonly missing: boolean;
    /** Whether the owning tab is visible; a hidden tab keeps the menu closed. */
    readonly visible: boolean;
    /** Read the branches whose names contain `query`; `signal` aborts the read. */
    readonly list: (query: string, signal: AbortSignal) => Promise<RemoteResult<ForgeBaseBranches>>;
    /** Compare with a branch, or with the automatic fork point for null. */
    readonly choose: (base: ForgeBaseBranch | null) => void;
}
/**
 * Render the trigger and, while open, the searchable menu. Opening and each
 * search read the branches again; rows already shown follow the search at once
 * until the new listing arrives.
 * @param props - the choice, the trigger label, the listing read, the choose action, and copy.
 * @returns the trigger with its portalled menu.
 */
export declare function BaseMenu({ chosen, label, missing, visible, list, choose, t }: BaseMenuProps): ReactNode;
//# sourceMappingURL=BaseMenu.d.ts.map