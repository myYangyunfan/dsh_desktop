/**
 * The thread list of a change request beside its changes: every thread grouped by file in file tree order, narrowed
 * by whether it is resolved, each opening the place it shows at. A wide changes view docks the list beside the files;
 * a narrower one floats it over them, and the narrowest gives it their whole width.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeDiffFile } from '../types.ts';
import { type ThreadFilter } from './review-threads.ts';
import type { NS } from './locales.ts';
import type { PlacedThread } from './thread-state.ts';
/** Props of the thread list. */
export interface ThreadListProps extends PropsLocale<typeof NS> {
    /** Every thread read, in host order, with where the current changes show it. */
    readonly entries: readonly PlacedThread[];
    /** Changed files in file tree order; threads on other paths follow them. */
    readonly files: readonly ForgeDiffFile[];
    /** Whether the host has more threads than were read. */
    readonly truncated: boolean;
    /** Web page of the change request. */
    readonly url: string;
    /** The active filter. */
    readonly filter: ThreadFilter;
    /** Choose a filter. */
    readonly choose: (filter: ThreadFilter) => void;
    /** Whether the reader just opened the list, so a list that covers the files takes the focus. */
    readonly claim: boolean;
    /** Report that the list handled `claim`. */
    readonly claimed: () => void;
    /** Open the place of a thread; `covering` says the list covers the files, so the owner closes it first. */
    readonly open: (entry: PlacedThread, covering: boolean) => void;
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Close the list at the reader's request. */
    readonly close: () => void;
}
/**
 * Render the thread list.
 * @param props - threads, their places, the file order, the filter, and the list's actions.
 * @returns the list pane and the scrim behind it where it floats over the files.
 */
export declare function ThreadList(props: ThreadListProps): ReactNode;
//# sourceMappingURL=ThreadList.d.ts.map