/**
 * One file of the changes view: a sticky header with the path, badges, line
 * counts, and file actions, then its hunks unified or side by side with the
 * unchanged lines between them collapsed into rows that expand them. A section
 * draws and highlights its lines once it comes within reach of the scrollport;
 * it redraws only when its own props change.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeDiffFile } from '../types.ts';
import { type FileThreads } from './ReviewThreads.tsx';
import { type ReviewActions } from './ReviewComposer.tsx';
import type { ForgePanelKey, NS } from './locales.ts';
import type { ViewedState } from './viewed-files.ts';
import type { SectionReach } from './section-reach.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** One action of a file's menu. */
export interface DiffFileAction {
    /** Dictionary key of the row label. */
    readonly label: ForgePanelKey;
    /** Runs the action. */
    readonly run: () => void;
}
/** New side of a file: its lines once read, `loading` while a read runs, or undefined before any. */
export type DiffFileText = readonly string[] | 'loading' | undefined;
/**
 * What every file section of one changes view calls. The view passes the same
 * object on every render, so a section redraws only when its own values change.
 */
export interface DiffFileHandlers {
    /** Expand or collapse a file. */
    readonly toggle: (file: ForgeDiffFile) => void;
    /** Show a large file anyway. */
    readonly reveal: (path: string) => void;
    /** Expand one gap of a file. */
    readonly expand: (file: ForgeDiffFile, index: number) => void;
    /** Mark a file viewed, which also collapses it, or clear the mark. */
    readonly view: (file: ForgeDiffFile, viewed: boolean) => void;
    /** Rows of a file's menu, read whenever the menu draws. */
    readonly actions: (file: ForgeDiffFile) => readonly DiffFileAction[];
    /** Receive a file's section element, which scrolling to the file targets, or null once it unmounts. */
    readonly section: (path: string, element: HTMLElement | null) => void;
    /** Show a file's next unresolved host thread in display order after the last one shown, or its first. */
    readonly nextThread: (path: string) => void;
    /** Tells each expanded section when it comes within reach of the scrollport, which draws its lines. */
    readonly reach: SectionReach;
}
/** Props of one file section. */
export interface DiffFileProps {
    /** Whether the owning tab is visible and may show temporary menus. */
    readonly visible: boolean;
    /** Comment destinations and the source being reviewed. */
    readonly review?: ReviewActions | undefined;
    /** The file and its hunks. */
    readonly file: ForgeDiffFile;
    /** Whether the section shows its lines. */
    readonly expanded: boolean;
    /** Whether the file shows the large-file notice instead of its lines until revealed. */
    readonly large: boolean;
    /** Whether the user revealed a large file. */
    readonly revealed: boolean;
    /** The file's new side, which supplies collapsed unchanged lines. */
    readonly text: DiffFileText;
    /** Indexes of the expanded gaps. */
    readonly open: ReadonlySet<number>;
    /** Whether deletions and additions show in two columns; a file with only additions or only deletions keeps one. */
    readonly split: boolean;
    /** Whether long lines wrap. */
    readonly wrap: boolean;
    /** Badge text after the path, or empty for none. */
    readonly badge: string;
    /** Hover text of the path: both paths of a renamed file, else the path. */
    readonly tooltip: string;
    /** Whether the reader marked this change viewed, or marked an earlier change of the file. */
    readonly viewed: ViewedState;
    /** Tooltip of the viewed mark: where marks are kept, or why the mark cannot change now. */
    readonly viewedNote: string;
    /** Whether the mark cannot change now, while its write is in flight or the host's marks could not be read. */
    readonly viewedDisabled: boolean;
    /** Review threads of the file from the code host, or undefined while none are read; the view keeps their identity. */
    readonly threads?: FileThreads | undefined;
    /** Whether the section draws its lines at once, as the target of a thread jump, whose card must exist to be centered. */
    readonly drawNow?: boolean | undefined;
    /** Actions shared by every section of the view. */
    readonly handlers: DiffFileHandlers;
    /** Forge panel copy. */
    readonly t: Translate;
}
/**
 * Render added and deleted line counts, or the binary label for binary content.
 * @param props - the counts and copy.
 * @returns the counts.
 */
export declare function Counts({ file, t }: {
    readonly file: Pick<ForgeDiffFile, 'additions' | 'deletions' | 'binary'>;
    readonly t: Translate;
}): ReactNode;
/**
 * Render one file of a diff. Until the section first comes within reach of the scrollport or a thread jump targets it,
 * an expanded file that draws lines shows a box of about their height instead.
 * @param props - the file, its section and gap state, layout choices, shared actions, and copy.
 * @returns the file section.
 */
declare function DiffFileSection(props: DiffFileProps): ReactNode;
/** One file of a diff, redrawn only when its props change. */
export declare const DiffFile: import("react").MemoExoticComponent<typeof DiffFileSection>;
export {};
//# sourceMappingURL=DiffFile.d.ts.map