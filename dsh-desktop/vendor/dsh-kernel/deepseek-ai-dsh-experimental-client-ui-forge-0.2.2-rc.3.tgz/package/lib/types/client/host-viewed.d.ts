/**
 * Viewed marks a code host keeps for a whole change request. The changes view reads them with the diff and shows each
 * mark the reader sets at once, while the host saves it; a mark the host refuses returns to what the host keeps, and a
 * mark the host may have saved stays.
 */
import type { ForgeViewedFiles, ForgeViewedRequest, ForgeViewedState } from '@deepseek-ai/dsh-experimental-forge/types';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeDiffFile } from '../types.ts';
import type { ViewedMarks } from './viewed-files.ts';
/** The host's marks on the files of one diff, or why the view could not read them. */
export type HostViewed = {
    readonly kind: 'read';
    readonly files: Readonly<Record<string, ForgeViewedState>>;
} | {
    readonly kind: 'failed';
    readonly message: string;
};
/** A loaded change request diff whose marks the host keeps. */
export interface HostViewedOwner {
    /** Binding URL of the change request. */
    readonly url: string;
    /** Head commit the diff and its marks were read at. */
    readonly headSha: string;
    /** Files of the diff with the digest of each change. */
    readonly files: readonly ForgeDiffFile[];
    /** The host's marks. */
    readonly viewed: HostViewed;
}
/**
 * Why a mark the host did not save returned to its previous state, or why the view cannot tell whether the host saved
 * a mark it keeps showing.
 */
export type HostViewedFailure = {
    readonly kind: 'stale';
} | {
    readonly kind: 'failed';
    readonly message: string;
} | {
    readonly kind: 'unknown';
    readonly message: string;
};
/** The host's marks of the shown diff with the reader's writes. */
export interface HostViewedMarks {
    /** Marks as digests, so a mark of the current change matches the file's digest and a dismissed mark matches none. */
    readonly marks: ViewedMarks;
    /** Whether the host's marks could not be read, so no file can be marked. */
    readonly unavailable: boolean;
    /** Whether a write of the file's mark is in flight. */
    readonly saving: (path: string) => boolean;
    /**
     * Show a mark at once and save it on the host.
     * @param path - the file's path.
     * @param viewed - whether the file is viewed.
     * @returns false, changing nothing, while the marks are unavailable or the file's previous write is in flight.
     */
    readonly mark: (path: string, viewed: boolean) => boolean;
}
/**
 * Convert the host's marks of a diff to digests, with the reader's choices taking the place of the host's.
 * @param files - files of the diff with the digest of each change.
 * @param host - the host's state of each file the host listed.
 * @param chosen - the reader's marks that apply to the diff, by path.
 * @returns the digest of each file marked viewed or dismissed.
 */
export declare function hostMarksOf(files: readonly ForgeDiffFile[], host: Readonly<Record<string, ForgeViewedState>>, chosen: ReadonlyMap<string, boolean>): ViewedMarks;
/**
 * Convert a read of the host's marks to the state the view keeps for a diff read at `headSha`.
 * @param result - the read, or null when the diff shows chosen commits, which the host keeps no marks for.
 * @param headSha - head commit the diff was read at.
 * @returns the marks, why they could not be read, or null when the browser keeps the marks instead.
 */
export declare function hostViewedOf(result: RemoteResult<ForgeViewedFiles | null> | null, headSha: string): HostViewed | null;
/**
 * Keep the reader's marks of a change request at one head over the host's, saving each on the host. A read at the same
 * head keeps the marks whose writes are in flight and their locks; a mark whose write settled stays until the next read,
 * which then holds what the host saved. A read at another head or of another change request starts without choices.
 * @param owner - the shown diff when the host keeps its marks, else null.
 * @param save - saves one mark on the host.
 * @param failed - reports a mark the host did not save after it returned to its previous state, or a mark the host may
 * not have saved.
 * @returns the marks and the write action, or null when the browser keeps the marks.
 */
export declare function useHostViewed(owner: HostViewedOwner | null, save: (url: string, request: ForgeViewedRequest) => Promise<RemoteResult<void>>, failed: (failure: HostViewedFailure) => void): HostViewedMarks | null;
//# sourceMappingURL=host-viewed.d.ts.map