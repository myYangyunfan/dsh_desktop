/**
 * Browser-persisted viewed marks of changed files. Each Session keeps one storage entry that maps a diff source,
 * such as a change request or a local scope with its base ref and chosen commits, to the digest of each file's
 * change when the reader marked it viewed. A mark whose digest differs from the file's current change reports the
 * file as changed since it was viewed. Several browser tabs of one Session share the entry: each mark rewrites the
 * entry as storage holds it, and marks saved by another tab reach this one through the `storage` event.
 */
/** Viewed state of one file in the diff a reader sees. */
export type ViewedState = 'viewed' | 'changed' | 'unviewed';
/** Digests of the files marked viewed in one source, by path; stable until a mark in that source changes. */
export type ViewedMarks = ReadonlyMap<string, string>;
/**
 * Classify a file by its mark.
 * @param marks - the marks of the source the diff shows.
 * @param path - the file's path.
 * @param digest - the digest of the file's current change.
 * @returns `viewed` for a mark of this change, `changed` for a mark of an earlier change, else `unviewed`.
 */
export declare function viewedStateOf(marks: ViewedMarks, path: string, digest: string): ViewedState;
/**
 * One Session's viewed marks. Unreadable storage shows no marks and refuses writes while it stays unreadable. While
 * anything subscribes, marks another tab saves replace the ones shown.
 */
export declare class ViewedFiles {
    private readonly session;
    private readonly now;
    private sources;
    private readonly listeners;
    private readonly snapshots;
    private readonly key;
    /**
     * @param session - storage identity of the Session, such as its id.
     * @param now - clock of the least-recently-marked bounds.
     */
    constructor(session: string, now?: () => number);
    /**
     * Read the marks of one source.
     * @param key - identity of the diff source.
     * @returns digests by path, the same object until a mark in the source changes.
     */
    readonly marksOf: (key: string) => ViewedMarks;
    /**
     * Observe changed marks.
     * @param listener - called after each saved mark.
     * @returns unsubscribe.
     */
    readonly subscribe: (listener: () => void) => (() => void);
    /**
     * Mark one file viewed at its current change or clear its mark, dropping the marks of paths the diff no longer has.
     * @param key - identity of the diff source.
     * @param files - every file of the diff with the digest of its change.
     * @param path - the file to mark.
     * @param viewed - whether the file is viewed.
     * @returns whether the mark was saved; the marks are unchanged when storage is unreadable or refuses the write.
     */
    mark(key: string, files: readonly {
        readonly path: string;
        readonly digest: string;
    }[], path: string, viewed: boolean): boolean;
    /** The saved marks of this Session, or undefined when storage cannot be read or holds an entry it cannot parse. */
    private load;
    /** Show the saved marks when they differ from the shown ones. */
    private reload;
    private replace;
    /** Another document changed this Session's entry, or with a null key cleared the whole storage. */
    private readonly stored;
    /** Move this Session to the front of the index and drop the marks of Sessions beyond {@link MAX_SESSIONS}. */
    private remember;
}
//# sourceMappingURL=viewed-files.d.ts.map