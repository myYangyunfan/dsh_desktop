/** macOS permission guide copy and private native request parameters. */
import { z } from 'zod';
import type { CuaBackend } from '@deepseek-ai/dsh-cua';
/** Native-only fields for opening the selected privacy pane. */
export declare const PermissionSettingsParameters: z.ZodObject<{
    settingsMessage: z.ZodString;
}, z.core.$strip>;
/** Native-only guide fields, validated again by the Swift request parser. */
export declare const PermissionGuideParameters: z.ZodObject<{
    settingsMessage: z.ZodString;
    instruction: z.ZodString;
    backLabel: z.ZodString;
    finderLabel: z.ZodString;
    unavailableMessage: z.ZodString;
    pollIntervalMs: z.ZodNumber;
}, z.core.$strip>;
/**
 * Resolve native permission copy from the Client language; unsupported languages use English.
 * @param pollIntervalMs Interval between native guide permission and position checks.
 * @returns Provider-owned parameters for the selected permission action.
 */
export declare function createPermissionParameters(pollIntervalMs: number): CuaBackend['permissionParameters'];
//# sourceMappingURL=permission-guide.d.ts.map