import type { Context } from '@deepseek-ai/cordis';
import type { CuaBackend } from '@deepseek-ai/dsh-cua';
/**
 * Keep native key ownership alive until its program returns, throws, or is interrupted.
 * @param ctx - Provider scope owning the tool execution listener.
 * @returns Handler for authorized directional keyboard requests.
 */
export declare function installHeldKeys(ctx: Context): NonNullable<CuaBackend['sendKeyEvent']>;
//# sourceMappingURL=held-keys.d.ts.map