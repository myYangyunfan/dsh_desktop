import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import { type CuaConfig } from '@deepseek-ai/dsh-cua';
import { type SourceSigning } from './native-build.ts';
export { GUIDANCE } from './guidance.ts';
/** Loader plugin identity. */
export declare const name = "experimental-cua-macos";
/** Services required by the shared CUA executor and the native launcher. */
export declare const inject: string[];
/** Native preparation, source-build signing, operation bounds, and profile-local application grants. */
export interface Config extends CuaConfig {
    /** Interval in milliseconds between permission and position checks while the native guide is open. */
    permissionPollIntervalMs: number;
    /**
     * Source-build signing: `ad-hoc` (default) binds grants to the code hash;
     * an object selects an existing certificate in an explicitly configured keychain.
     * Installed packages and `helperPath` keep their own signature.
     */
    sourceSigning: SourceSigning;
}
/** Validate shared operation bounds and macOS source signing before preparing the helper. */
export declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
    permissionPollIntervalMs: Schema<number, number, "defined">;
    sourceSigning: Schema<"ad-hoc" | ({
        identity?: string | null;
        keychain?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict), "ad-hoc" | Schemastery.ObjectT<NoInfer<{
        identity: Schema<string, string, "defined">;
        keychain: Schema<string, string, "defined">;
    }>>, "defined">;
    requireSystemPointerApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
    permissionPollIntervalMs: Schema<number, number, "defined">;
    sourceSigning: Schema<"ad-hoc" | ({
        identity?: string | null;
        keychain?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict), "ad-hoc" | Schemastery.ObjectT<NoInfer<{
        identity: Schema<string, string, "defined">;
        keychain: Schema<string, string, "defined">;
    }>>, "defined">;
    requireSystemPointerApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
}>>, "plain">;
/**
 * Mount logged native operations with separate Agent connections to the shared helper.
 * @param ctx - Host context with computer-use, subprocess and tool services.
 * @param config - Validated native preparation and operation bounds.
 * @returns Completion after native preparation and tool registration.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map