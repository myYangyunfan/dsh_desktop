import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** Architecture names used by the platform-specific native payload. */
export type NativeArchitecture = 'arm64' | 'x64';
/** Signature selected for source builds; certificates are created and unlocked by the developer. */
export type SourceSigning = 'ad-hoc' | {
    /** Existing codesign certificate name or SHA-1 fingerprint, without a leading dash or whitespace. */
    identity: string;
    /** Absolute keychain path. */
    keychain: string;
};
/**
 * Validate the host before preparing a platform-specific application.
 * @param platform - Node host platform.
 * @param architecture - Node host architecture.
 * @returns Supported macOS architecture.
 * @throws When the current host has no native implementation.
 */
export declare function nativeHostArchitecture(platform: string, architecture: string): NativeArchitecture;
/** Explicit compiler ownership and resource limits for one preparation. */
export interface NativeBuildSpec {
    packageRoot: string;
    architecture: NativeArchitecture;
    /** Signature of a source-checkout build; installed packages ignore it. */
    sourceSigning: SourceSigning;
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
    signal: AbortSignal;
    timeoutMs: number;
    graceMs: number;
}
/**
 * Resolve the immutable application selected by a packaged or source-build receipt.
 * @param directory - Architecture-specific directory containing current.json and application generations.
 * @param variant - Development or release application filename selected by the build or installation.
 * @returns Executable inside the selected application bundle.
 * @throws When the receipt is invalid or the application executable is missing.
 */
export declare function nativeExecutablePath(directory: string, variant: 'release' | 'dev'): Promise<string>;
/**
 * Recognize the repository-owned package location before allowing local compilation.
 * @param packageRoot - Real directory containing the CUA package manifest.
 * @returns True only for a CUA package in a DSH source checkout.
 */
export declare function isSourcePackage(packageRoot: string): Promise<boolean>;
/**
 * Build and sign an immutable development helper application with the selected Apple developer tools.
 * The development variant has its own bundle identifier and the signature selected by `spec.sourceSigning`.
 * @param spec - Checkout, target, managed process provider and cancellation/deadline limits.
 * @returns Executable inside the prepared application, after complete compiler cleanup.
 * @throws When preparation, cancellation, resource cleanup or receipt validation fails.
 */
export declare function buildNativeExecutable(spec: NativeBuildSpec): Promise<string>;
/**
 * Prepare source builds on activation; installed packages carry their signed application.
 * A package inside an Electron `app.asar` archive reads its application from the sibling `app.asar.unpacked`
 * directory, which the Desktop installer populates so LaunchServices and process spawning can open the bundle.
 * @param spec - Native preparation inputs for this host.
 * @returns Executable inside a ready application without compiling or re-signing an installed package.
 * @throws When an installed package carries no application receipt, naming the directory that was expected to hold it.
 */
export declare function prepareNativeExecutable(spec: NativeBuildSpec): Promise<string>;
//# sourceMappingURL=native-build.d.ts.map