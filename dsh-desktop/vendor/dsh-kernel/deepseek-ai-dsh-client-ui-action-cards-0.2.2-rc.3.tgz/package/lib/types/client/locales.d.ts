/** English card frame, fallback and tool-row copy. */
export declare const en: {
    expandBrief: string;
    collapseBrief: string;
    dismiss: string;
    dismissed: string;
    replaced: string;
    unavailable: string;
    transport: string;
    'row.title': string;
    'row.preparing': string;
    'row.running': string;
    'row.ok': string;
    'row.error': string;
    'row.stopped': string;
    'row.inspect': string;
};
/** Keys shared by every dictionary. */
export type ActionCardKey = keyof typeof en;
/** Chinese card frame, fallback and tool-row copy. */
export declare const zh: Record<ActionCardKey, string>;
/** Japanese card frame, fallback and tool-row copy. */
export declare const ja: Record<ActionCardKey, string>;
/** Spanish card frame, fallback and tool-row copy. */
export declare const es: Record<ActionCardKey, string>;
/** French card frame, fallback and tool-row copy. */
export declare const fr: Record<ActionCardKey, string>;
/** German card frame, fallback and tool-row copy. */
export declare const de: Record<ActionCardKey, string>;
/** Russian card frame, fallback and tool-row copy. */
export declare const ru: Record<ActionCardKey, string>;
/** Portuguese card frame, fallback and tool-row copy. */
export declare const pt: Record<ActionCardKey, string>;
//# sourceMappingURL=locales.d.ts.map