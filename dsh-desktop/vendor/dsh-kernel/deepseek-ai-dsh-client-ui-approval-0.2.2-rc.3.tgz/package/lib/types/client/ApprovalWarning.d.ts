import type { ApprovalCardInput } from './contract/slots.ts';
/**
 * Present caller-owned risks on hover, keyboard focus, or touch activation.
 * @param props Localized warning content.
 * @returns The warning tag and its readable, nonmodal hover card.
 */
export declare function ApprovalWarning({ warning }: {
    warning: NonNullable<ApprovalCardInput['warning']>;
}): import("react").JSX.Element;
//# sourceMappingURL=ApprovalWarning.d.ts.map