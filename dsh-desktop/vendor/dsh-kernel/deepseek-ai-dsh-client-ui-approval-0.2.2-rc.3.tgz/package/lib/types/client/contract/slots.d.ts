/** Approval composer and optional correlated-detail contracts. */
import type { ToolCallId } from '@deepseek-ai/dsh-llm';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { PropsLocale, PropsRenderFactories, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ApprovalKey } from '../locales.ts';
declare module '@deepseek-ai/dsh-client-ui-session/client' {
    interface SessionPendingInteractionMap {
        /** Pending approval request. */
        approval: PendingApproval;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Approval prompt copy. */
        approval: ApprovalKey;
    }
    interface SlotFactoryMap {
        /** Shared decision card; the caller owns authorization and persistence. */
        'conversation.approval.card': {
            scope: 'session';
            props: ApprovalCardInput;
            locale: 'approval';
            children: {
                'conversation.approval.detail': {
                    kind: 'single';
                    scope: 'session';
                };
            };
        };
    }
    interface SlotMap {
        /** Optional detail for the Tool call correlated with an approval request. */
        'conversation.approval.detail': {
            kind: 'single';
            scope: 'session';
            owner: ApprovalDetailOwnerProps;
        };
    }
}
/** Stable identity handed to an optional approval-detail renderer. */
export interface ApprovalDetailOwnerProps {
    /** Tool call correlated with the request. */
    callId: ToolCallId;
}
/** Client-visible fields of an approval request projected through Remote Events. */
export interface ApprovalPresentationRequest {
    /** Tool requesting the decision. */
    readonly toolName: string;
    /** Tool call correlated with the request. */
    readonly callId?: ToolCallId;
    /** Human-readable reason supplied by the requester. */
    readonly reason?: string;
    /** Localized presentation copy; the audit reason remains unchanged. */
    readonly displayReason?: {
        readonly en: string;
        readonly [locale: string]: string;
    };
    /** Cancellation projected from the Host waterfall. */
    readonly signal?: AbortSignal;
}
/** Decisions this interactive Client presentation can return. */
export type ApprovalDecision = 'allowed-once' | 'rejected';
/** Domain discriminator literal carried by {@link PendingApproval.kind}. */
export type ApprovalInteractionKind = 'approval';
/** One answerable Client presentation of a pending Host waterfall. */
export declare class PendingApproval {
    #private;
    readonly sessionId: SessionId;
    /** Domain discriminator used by Session pending-interaction consumers. */
    readonly kind: 'approval';
    /** Opaque render identity and one-shot remount axis. */
    readonly key: string;
    /** Tool requesting the decision. */
    readonly toolName: string;
    /** Correlated Tool call, when supplied by the asker. */
    readonly callId: ToolCallId | undefined;
    /** Human-readable reason supplied by the asker. */
    readonly reason: string | undefined;
    /** Localized presentation copy, when supplied by the asker. */
    readonly displayReason: ApprovalPresentationRequest['displayReason'];
    /** Result returned by the Remote Event listener to the Host waterfall. */
    readonly result: Promise<ApprovalDecision>;
    /**
     * @param sessionId - Agent/Session identity owning the scoped request.
     * @param request - Host approval request projected through the Remote Event.
     */
    constructor(sessionId: SessionId, request: ApprovalPresentationRequest);
    /**
     * Availability of this pending request after answer or withdrawal.
     * @returns whether this request can still accept a decision.
     */
    get answerable(): boolean;
    /**
     * Resolve the Host waterfall with the user's decision.
     * @param outcome - supported interactive decision.
     */
    answer(outcome: ApprovalDecision): Promise<void>;
    /** Delegate an unanswered request to the next waterfall listener. */
    delegate(): void;
    /**
     * Test whether a rejection requests waterfall delegation.
     * @param reason - rejection received from {@link PendingApproval.result}.
     * @returns whether {@link PendingApproval.delegate} produced it.
     */
    isDelegation(reason: unknown): boolean;
    /**
     * End an unanswered presentation when its transport, scope, or plugin lifetime ends.
     * @param reason - rejection exposed to the waiting Remote Event listener.
     */
    abort(reason: unknown): void;
    private finish;
}
/** Locale lookup supplied by the approval registration. */
export interface ApprovalInjected {
    /**
     * Resolve requester-owned copy in the current UI language.
     * @param reason - localized presentation text with an English fallback.
     * @returns text for the active UI language.
     */
    resolveReason(reason: NonNullable<ApprovalPresentationRequest['displayReason']>): string;
}
/** Full props of the approval composer takeover. */
export type ApprovalComposerProps = PropsRuntime<'conversation.composer'> & PropsRenderFactories & {
    matched: PendingApproval;
} & PropsLocale<'approval'> & ApprovalInjected;
/** Data and decisions accepted by the shared approval card. */
export interface ApprovalCardInput {
    /** Identity whose change resets the pending submission. */
    requestKey: string;
    /** Localized question describing the requested operation. */
    title: string;
    /** Localized scope or consequence of the decision. */
    description?: string;
    /** Caller-localized warning label and explanation, with paragraphs separated by blank lines (`\n\n`). */
    warning?: {
        label: string;
        title: string;
        detail: string;
    };
    /** Subject metadata for human recognition; the caller admits icon URLs. Never an authorization identity. */
    subject?: {
        name: string;
        icon?: string;
    };
    /** Optional tool-owned detail rendered through the existing child slot. */
    callId?: ToolCallId;
    /** Caller-specific scope label; ordinary approvals use Allow once. */
    allowLabel?: string;
    /** Whether the caller still accepts an answer. */
    canAnswer: () => boolean;
    /** Grant this request with the caller's stated scope. */
    onAllow: () => Promise<void>;
    /** Refuse this request. */
    onReject: () => Promise<void>;
    /** Explicit persistent choice; absent when the caller cannot save permission. */
    onAlways?: () => Promise<void>;
}
//# sourceMappingURL=slots.d.ts.map