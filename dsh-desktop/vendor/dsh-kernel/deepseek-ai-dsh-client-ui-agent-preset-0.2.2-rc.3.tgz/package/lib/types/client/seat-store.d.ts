/**
 * Hero-chip controller: which preset the NEXT session gets.
 *
 * The new-session screen has no session, so a pick is staged rather than
 * applied. It reaches a session when one becomes current and is still blank —
 * whether the workspace connect created it or reused an existing blank one. A
 * flow that knows its preset before it starts (the settings section's creator
 * entry) passes it to session creation instead, and its stage only drives the
 * chip's display.
 *
 * The stage is forgotten once applied. The next new session starts from the
 * Host-effective default again.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { SessionSummary } from '@deepseek-ai/dsh-api-session-controller/client';
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { AgentPresetOption } from './settings-store.ts';
/** Hero-chip snapshot. */
export interface AgentPresetSeatState {
    /** Presets the deployment supplies; empty means the chip renders nothing. */
    options: readonly AgentPresetOption[];
    /** The staged choice, empty until the roster loads. */
    current: string;
    /** An error message; explicit selection failures also carry the preset for a Toast. */
    error: string | {
        readonly preset: AgentPresetOption;
        readonly reason: string;
    } | null;
    busy: boolean;
    /**
     * One-shot cue that the chip should introduce itself (the creator-draft
     * entry staged the pick from another screen, so the user never touched the
     * chip); the renderer clears it via `introduced()` once played.
     */
    introduce: boolean;
}
/** Mutable one-shot preset choice shared across Provider-bound seat controllers. */
export interface AgentPresetStage {
    /** Preset awaiting application; absence means no staged choice. */
    id: string | undefined;
    /** Whether the receiving chip should announce the applied choice once. */
    introduce: boolean;
}
/**
 * Result of one attempt to hand a staged preset to the current Session: the Host applied it,
 * it waits for a Session to appear, nothing changed (busy, already composed, started, or no
 * stage), or the Host refused it.
 */
export type AgentPresetApplyOutcome = {
    readonly kind: 'applied' | 'staged' | 'unchanged';
} | {
    readonly kind: 'refused';
    readonly reason: string;
};
/** Stages the next session's preset and applies it when one appears. */
export declare class AgentPresetSeatController {
    private readonly ctx;
    /** The session the hero is about to hand over to, when there is one. */
    private readonly currentSession;
    private readonly staged;
    /** Chip snapshot the renderer subscribes to. */
    readonly store: SnapshotStore<AgentPresetSeatState>;
    /**
     * The Host-effective default, so a consumed stage can fall back to it without
     * re-reading the roster.
     */
    private fallback;
    /** Only the newest roster read may publish after overlapping refreshes. */
    private loadGeneration;
    /** Completion of the active Host selection; Settings choices wait before staging. */
    private pendingSelection;
    constructor(ctx: ClientContext, 
    /** The session the hero is about to hand over to, when there is one. */
    currentSession: () => Pick<SessionSummary, 'id' | 'blank' | 'projectionValues'> | undefined, staged?: AgentPresetStage);
    private set;
    private clearStage;
    /**
     * Read the roster and open the chip on the Host-effective default.
    * @returns once the snapshot reflects the host.
    */
    load(): Promise<void>;
    /**
     * Stage one preset for the next session, applying it immediately when a
     * blank session is already current.
     *
     * The refusal is stored for the chip's announcement and returned to callers
     * such as Settings that also report the result of their own write.
     * @param id - the preset to stage.
     * @returns how the pick settled; a refusal carries its text.
     */
    select(id: string): Promise<AgentPresetApplyOutcome>;
    /**
     * Stage a pick WITHOUT the immediate apply, for a flow that starts the
     * receiving session after the pick (the settings section's creator entry).
     * `select()`'s immediate apply would meet the still-current running session
     * and drop the stage as unservable; staging alone leaves it for the
     * list-change applier, which fires when the started session becomes
     * current.
     * @param id - the preset to stage.
     * @param introduce - true when the stage came from another screen and the
     * chip should announce itself on the session it lands on.
     */
    stage(id: string, introduce?: boolean): void;
    /** Acknowledge a displayed refusal without dismissing a newer attempt.
     * @param refusal - the selection error whose Toast finished.
     */
    dismissRefusal(refusal: AgentPresetSeatState['error']): void;
    /**
     * Capture the exact blank Session a Settings action may bring along.
     * @returns its id, or undefined outside a blank Session.
     */
    blankSessionId(): SessionSummary['id'] | undefined;
    /**
     * Apply a Settings choice only if its captured Session is still current and
     * blank after any pending selection settles. The selection uses the existing stage/apply path.
     * @param expectedSessionId - blank Session captured before the Settings write.
     * @param id - the effective default that the write persisted.
     * @returns the Host refusal text, or undefined when applied or no longer relevant.
     */
    syncBlankSession(expectedSessionId: SessionSummary['id'], id: string): Promise<string | undefined>;
    /** Acknowledge the introduction cue once the chip has played it. */
    introduced(): void;
    /**
     * Hand the staged choice to the current session, if there is one to take it.
     *
     * Called both by `select()` and by whoever observes the current session
     * changing, because the session may appear either before or after the pick.
     * List updates do not repeat a selection while its response is pending.
     * @returns how this attempt settled; only a Host commit of the staged preset is applied.
     */
    apply(): Promise<AgentPresetApplyOutcome>;
}
//# sourceMappingURL=seat-store.d.ts.map