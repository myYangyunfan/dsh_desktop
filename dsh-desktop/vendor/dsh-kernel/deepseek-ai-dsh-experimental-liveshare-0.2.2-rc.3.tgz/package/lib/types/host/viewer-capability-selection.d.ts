/**
 * Reading one share's owner-submitted plugin policy against the platform catalog.
 *
 * A submission is accepted only where the plugin and every named endpoint are still offered. The
 * result is what the share record carries: absent when nothing is exposed, so an old record without
 * the field keeps meaning "none".
 * @module @deepseek-ai/dsh-experimental-liveshare/src/host/viewer-capability-selection
 */
import type { ShareablePluginCatalog, ViewerPluginPolicy } from './viewer-capability-types.ts';
/** Why one submission was refused. */
export type ViewerPluginPolicyRefusal = {
    readonly code: 'invalid-capabilities';
} | {
    readonly code: 'unknown-plugin';
    readonly plugin: string;
} | {
    readonly code: 'endpoint-not-offered';
    readonly plugin: string;
    readonly endpoint: string;
};
/** The accepted policies, or the refusal that replaces them. */
export type ViewerPluginPolicySelection = {
    readonly ok: true;
    /** Policies that expose at least one endpoint, or undefined when the share exposes none. */
    readonly selection: readonly ViewerPluginPolicy[] | undefined;
} | {
    readonly ok: false;
    readonly refusal: ViewerPluginPolicyRefusal;
};
/**
 * Accept one submission against the endpoints the platform catalog offers.
 * @param offered - Catalog grouped by plugin.
 * @param input - Submitted `viewerPlugins` value, of any type.
 * @returns The policies to store, or the refusal that replaces them.
 */
export declare function readViewerPluginPolicies(offered: readonly ShareablePluginCatalog[], input: unknown): ViewerPluginPolicySelection;
//# sourceMappingURL=viewer-capability-selection.d.ts.map