/**
 * Installed-plugin Remote methods a share may offer its viewers.
 *
 * The catalog is read from the Host's live local Typert registry: every method the current
 * composition registers belongs to a namespace, and namespaces that belong to DSH core services or
 * LiveShare itself are excluded. The owner still chooses which of the remaining methods one share
 * exposes; the catalog only states the offer, and never distinguishes read from write.
 *
 * Each group also carries the registering package and that package's localized plugin titles, so the
 * share dialog can show a product name instead of a wire namespace.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/host/shareable-catalog
 */
import type { ShareablePluginCatalog } from './viewer-capability-types.ts';
/**
 * Namespaces whose methods never enter the share catalog.
 *
 * These are DSH core services, Session/Workspace plumbing, the plugin manager, and LiveShare's own
 * management Remote. A method that is not listed stays governed by the existing share roles.
 */
export declare const EXCLUDED_SHARE_NAMESPACES: ReadonlySet<string>;
/** What one package contributes to a catalog group. */
export interface PluginMetadata {
    /** Package name parsed from the descriptor id, when the id names one. */
    readonly package?: string;
    /** Localized plugin titles keyed by language. */
    readonly titles?: Readonly<Record<string, string>>;
    /** Feature bundle that introduces this component; components of one bundle share a row. */
    readonly bundle?: string;
    /** Whether the component belongs to a core profile bundle rather than an installable feature. */
    readonly core?: boolean;
}
/** Read one package's display metadata; injected so catalog tests need no installed package. */
export type PluginMetadataReader = (packageName: string) => PluginMetadata;
/**
 * Find one package directory by looking for its manifest under the resolver's search paths.
 *
 * The package entry itself may not exist on the source plane, so this looks only for the manifest
 * beside the package name rather than resolving the entry module.
 * @param packageName - Package that registered the namespace.
 * @param searchPaths - Directories the package may live under; defaults to Node's resolution paths.
 * @returns The package directory, or undefined when this Host cannot find its manifest.
 */
export declare function packageRoot(packageName: string, searchPaths?: readonly string[]): string | undefined;
/**
 * Read a package's localized plugin titles.
 * @param root - Package directory.
 * @returns Titles keyed by language, or undefined when the package ships no title.
 */
export declare function readTitles(root: string): Readonly<Record<string, string>> | undefined;
/**
 * Read one package's display metadata.
 * @param packageName - Package that registered the namespace.
 * @returns The package name and titles this Host could read.
 */
export declare function readPluginMetadata(packageName: string): PluginMetadata;
/** The part of the Host's local Typert registry this catalog reads. */
export interface ShareableEndpointRegistry {
    /**
     * Snapshot the Host's local invocation descriptors.
     * @returns One descriptor per registered Remote method.
     */
    list(): readonly {
        readonly id: string;
        readonly namespace: string;
        readonly method: string;
        readonly description?: string;
    }[];
}
/**
 * Build the catalog from the live local Typert registry.
 * @param local - The Host's local Typert registry, when the composition mounts Typert.
 * @param readMetadata - Package metadata reader; defaults to reading the installed package.
 * @returns One group per included namespace, sorted by namespace and then endpoint.
 */
export declare function shareableViewerCatalog(local?: ShareableEndpointRegistry, readMetadata?: PluginMetadataReader): readonly ShareablePluginCatalog[];
//# sourceMappingURL=shareable-catalog.d.ts.map