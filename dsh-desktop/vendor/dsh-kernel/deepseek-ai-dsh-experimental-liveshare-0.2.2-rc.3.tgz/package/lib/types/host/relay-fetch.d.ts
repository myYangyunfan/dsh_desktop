/**
 * Relay HTTP calls over a connection owned by one share host.
 *
 * Each transport owns its dispatcher: it honours the process proxy policy but does not replace the
 * global dispatcher. HTTP/2 stays enabled; undici's informational idle-teardown error is consumed by a
 * Relay-scoped socket guard instead of reaching the process fail-loud path. A replaced
 * `globalThis.fetch` is deliberately ignored so instrumentation cannot move Relay traffic onto the
 * shared transport.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/host/relay-fetch
 */
import type { RequestInit, Response } from 'undici';
/** Send one Relay request. */
export type RelayFetch = (input: string | URL, init?: RequestInit) => Promise<Response>;
/** Lookup shape the proxy policy resolves from. */
export type RelayEnvironment = (name: string) => {
    readonly value: string;
} | undefined;
/** One host-owned Relay transport and the connection pool it must close. */
export interface RelayTransport {
    readonly fetch: RelayFetch;
    close(): Promise<void>;
}
/**
 * Resolve one proxy setting from the process environment.
 * @param name - environment variable name.
 * @returns the value in the proxy lookup shape, or undefined when absent.
 */
export declare function processRelayEnvironment(name: string): {
    readonly value: string;
} | undefined;
/**
 * Create one Relay transport with a dispatcher owned by the caller.
 * @param environment - proxy lookup; defaults to the process environment.
 * @returns the fetch function and the close operation that releases its pool.
 */
export declare function createRelayTransport(environment?: RelayEnvironment): RelayTransport;
/**
 * Resolve the module-level transport through another environment lookup.
 * @param lookup - proxy lookup, usually a launcher snapshot.
 */
export declare function configureRelayFetchEnvironment(lookup: RelayEnvironment): void;
/**
 * Send one Relay request over the module-level transport.
 * @param input - absolute Relay URL or URL object.
 * @param init - request options.
 * @returns the Relay response.
 */
export declare function relayFetch(input: string | URL, init?: RequestInit): Promise<Response>;
/** Close the module-level transport, if it has a pool. */
export declare function closeRelayFetch(): Promise<void>;
//# sourceMappingURL=relay-fetch.d.ts.map