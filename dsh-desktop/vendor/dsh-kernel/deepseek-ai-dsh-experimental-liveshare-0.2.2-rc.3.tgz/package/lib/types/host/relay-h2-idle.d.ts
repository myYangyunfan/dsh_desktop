/**
 * Consume undici's HTTP/2 idle-session teardown for Relay requests only.
 *
 * undici reports an idle h2 close as `InformationalError('socket idle timeout')` on a socket no
 * request owns. The Relay keeps HTTP/2, so this guard observes connected sockets only while a
 * Relay request is on the async call stack. Sockets opened by any other component are left alone.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/host/relay-h2-idle
 */
/**
 * Run one Relay request inside the guard's async scope.
 * @param operation - the request to run.
 * @returns the operation result.
 */
export declare function runRelayH2Scoped<T>(operation: () => Promise<T>): Promise<T>;
/**
 * Whether a value is undici's HTTP/2 idle-timeout notification.
 * @param error - The emitted socket error.
 * @returns True for the informational idle timeout.
 */
export declare function isRelayH2IdleTimeout(error: unknown): boolean;
/** Install the diagnostics listener once. */
export declare function armRelayH2Guard(): void;
//# sourceMappingURL=relay-h2-idle.d.ts.map