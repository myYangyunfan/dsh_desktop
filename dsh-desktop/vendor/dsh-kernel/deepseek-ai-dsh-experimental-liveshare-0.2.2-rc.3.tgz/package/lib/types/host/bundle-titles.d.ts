/**
 * User-facing bundle titles for the packages that register Remote methods.
 *
 * A shipped optional feature is a bundle package whose patch rows mount one or more component
 * packages. The experimental-plugin page names the bundle; a Remote method names its component
 * package. Preferring the containing bundle's localized title keeps the share dialog and the plugin
 * page in agreement. A component no bundle mounts falls back to its own package title.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/host/bundle-titles
 */
/** Localized titles keyed by lowercase language id. */
export type BundleTitles = Readonly<Record<string, string>>;
/** One bundle that introduces component packages. */
export interface BundleTitleEntry {
    readonly name: string;
    /** Localized title; absent on a core bundle that ships no display metadata. */
    readonly titles?: BundleTitles;
    /** Whether this is a profile/core bundle rather than an installable feature. */
    readonly core: boolean;
}
/** One localized title source the share host reads from the plugin manager. */
export interface BundleTitleMeta {
    readonly title?: unknown;
}
/** One bundle row that mounts a component package. */
export interface BundleTitleRow {
    readonly moduleName?: string;
}
/** The subset of a plugin-manager bundle this module reads. */
export interface BundleTitleBundle {
    readonly name?: string;
    readonly meta?: BundleTitleMeta;
    readonly rows?: readonly BundleTitleRow[];
}
/** The subset of the plugin manager service this module reads. */
export interface BundleTitleSource {
    listBundles(): Promise<readonly BundleTitleBundle[]>;
}
/**
 * Index every bundle's row module names to the bundle title that introduces them.
 * @param bundles - Bundle catalog reported by the plugin manager.
 * @returns Component package name to the feature bundle that introduces it.
 */
export declare function bundleTitleMap(bundles: readonly BundleTitleBundle[]): ReadonlyMap<string, BundleTitleEntry>;
/**
 * Read the bundle titles of the current profile.
 * @param manager - The plugin manager mounted by this Host.
 * @returns Component package name to bundle entry map, empty when the catalog cannot be read.
 */
export declare function bundleTitlesOf(manager: BundleTitleSource): Promise<ReadonlyMap<string, BundleTitleEntry>>;
//# sourceMappingURL=bundle-titles.d.ts.map