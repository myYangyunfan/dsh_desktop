/**
 * The share dialog's installed-plugin method control and the helpers that read one share's policies.
 *
 * One global switch opens every installed plugin's offered methods, closes them all, or follows the
 * per-plugin list. Each plugin is then closed, open for every offered method, or a subset. A full
 * selection is stored as `all`; a subset stores its explicit endpoints.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/client/ShareCapabilitiesPicker
 */
import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
import type { OfferedPlugin, ViewerPluginPolicy } from './share-types.ts';
/** How one plugin's offered methods appear for one share. */
export type PluginExposure = 'none' | 'all' | 'partial';
/** The share's global switch over installed plugin methods. */
export type PluginAccess = 'all' | 'none' | 'custom';
/**
 * The product name to show for one plugin group.
 *
 * A localized title from the package's locale files wins; English is the fallback. A missing or
 * package-shaped English title falls back to the package's last segment, then to the namespace.
 * @param group - Offered plugin.
 * @param language - Active interface language.
 * @returns The display name.
 */
export declare function pluginDisplayName(group: OfferedPlugin, language: string): string;
/**
 * The exposure one plugin has in a share's policies.
 * @param selection - Policies the share record names.
 * @param plugin - Plugin namespace to read.
 * @returns The exposure for that plugin.
 */
export declare function pluginExposure(selection: readonly ViewerPluginPolicy[], plugin: string): PluginExposure;
/**
 * The endpoints one policy effectively exposes for one offered plugin.
 * @param offered - Catalog the host currently offers.
 * @param policy - Policy to expand.
 * @returns The endpoints the policy names, or an empty list when the plugin is not offered.
 */
export declare function policyEndpoints(offered: readonly OfferedPlugin[], policy: ViewerPluginPolicy): readonly string[];
/**
 * Whether one endpoint is exposed by a share's policies.
 * @param offered - Catalog the host currently offers.
 * @param selection - Policies the share record names.
 * @param plugin - Plugin namespace to read.
 * @param endpoint - Endpoint to test.
 * @returns True when the endpoint is exposed.
 */
export declare function endpointSelected(offered: readonly OfferedPlugin[], selection: readonly ViewerPluginPolicy[], plugin: string, endpoint: string): boolean;
/**
 * Set one plugin's exposure.
 * @param offered - Catalog the host currently offers.
 * @param selection - Current policies.
 * @param plugin - Plugin namespace to change.
 * @param exposure - Exposure to set.
 * @returns The new policies.
 */
export declare function setPluginExposure(offered: readonly OfferedPlugin[], selection: readonly ViewerPluginPolicy[], plugin: string, exposure: PluginExposure): readonly ViewerPluginPolicy[];
/**
 * Select or clear one endpoint for a plugin.
 * @param offered - Catalog the host currently offers.
 * @param selection - Current policies.
 * @param plugin - Plugin namespace to change.
 * @param endpoint - Endpoint to change.
 * @param selected - Whether it should be exposed.
 * @returns The new policies.
 */
export declare function setEndpointSelected(offered: readonly OfferedPlugin[], selection: readonly ViewerPluginPolicy[], plugin: string, endpoint: string, selected: boolean): readonly ViewerPluginPolicy[];
/**
 * Narrow one policy list to what the host currently offers, dropping closed plugins.
 * @param offered - Catalog the host currently offers.
 * @param selection - Policies to write back.
 * @returns The policies the owner API accepts for this catalog.
 */
export declare function selectionForOffered(offered: readonly OfferedPlugin[], selection: readonly ViewerPluginPolicy[]): readonly ViewerPluginPolicy[];
/**
 * The endpoints one policy list exposes, as comparable keys.
 * @param offered - Catalog the host currently offers.
 * @param selection - Policies read from a share record.
 * @returns One key per exposed endpoint, sorted.
 */
export declare function selectionKeys(offered: readonly OfferedPlugin[], selection: readonly ViewerPluginPolicy[]): readonly string[];
/**
 * Whether two key lists name exactly the same endpoints.
 * @param left - One sorted key list.
 * @param right - The other sorted key list.
 * @returns True when both name the same endpoints once each.
 */
export declare function sameKeys(left: readonly string[], right: readonly string[]): boolean;
/** Props for the plugin-method control. */
export interface ShareCapabilitiesPickerProps extends PropsLocale<typeof NS> {
    /** Installed plugins the Host currently offers; an empty list renders only the global switch. */
    readonly offered: readonly OfferedPlugin[];
    /** Global switch this share carries. */
    readonly access: PluginAccess;
    /** Policies this share carries. */
    readonly selection: readonly ViewerPluginPolicy[];
    /** Whether the control is unavailable. */
    readonly disabled: boolean;
    /** Base id the per-plugin controls derive from. */
    readonly controlId: string;
    /** Record the owner's global switch. */
    readonly onAccessChange: (access: PluginAccess) => void;
    /** Record the owner's per-plugin selection. */
    readonly onChange: (selection: readonly ViewerPluginPolicy[]) => void;
}
/**
 * Render the global switch, a search field, and one row per installed plugin with its method
 * checkboxes for a partial selection. Only the custom switch shows the per-plugin list.
 * @param props - The live catalog, the current policies, and localized copy.
 * @returns The control, or nothing when no plugin offers a method.
 */
export declare function ShareCapabilitiesPicker({ offered, access, selection, disabled, controlId, onAccessChange, onChange, t, }: ShareCapabilitiesPickerProps): ReactNode;
//# sourceMappingURL=ShareCapabilitiesPicker.d.ts.map