/** Chip title of the forge tab: the change request glyph and the localized tab name. */
import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
/**
 * Render the tab chip title in the current UI language.
 * @param props - forge panel copy.
 * @returns the glyph followed by the tab name.
 */
export declare function ForgeTabTitle({ t }: PropsLocale<typeof NS>): ReactNode;
//# sourceMappingURL=ForgeTabTitle.d.ts.map