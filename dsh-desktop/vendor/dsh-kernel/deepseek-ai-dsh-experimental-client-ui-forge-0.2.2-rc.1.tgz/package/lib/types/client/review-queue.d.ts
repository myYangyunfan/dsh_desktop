/** Browser-persisted review drafts and the write whose outcome still needs confirmation. */
import type { ForgeReviewRequest } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ReviewSelection, ReviewSource } from './review.ts';
/** A comment retained after adding its reference or receiving a publication receipt. */
export type ReviewRecord = {
    readonly kind: 'agent';
    readonly selection: ReviewSelection;
} | {
    readonly kind: 'published';
    readonly selection: ReviewSelection;
    readonly url: string;
};
/** One inline record; its numeric key belongs only to the retained browser store. */
export type ReviewThread = {
    readonly key: number;
} & (ReviewRecord | {
    readonly kind: 'pending';
    readonly selection: ReviewSelection;
});
/** File-scoped snapshot that does not change while unrelated comments or the summary are edited. */
export interface FileReviewState {
    readonly threads: readonly ReviewThread[];
    readonly locked: boolean;
    readonly error: ReviewQueueState['error'];
}
/** Stable snapshot for a file without a comment store. */
export declare const EMPTY_FILE_REVIEW: FileReviewState;
/** Immutable queue snapshot; errors leave the original stored bytes untouched. */
export interface ReviewQueueState {
    readonly comments: readonly ReviewSelection[];
    readonly records: readonly ReviewRecord[];
    readonly body: string;
    readonly event: 'comment' | 'approve' | 'request-changes';
    readonly uncertain: ForgeReviewRequest | null;
    readonly error: 'load' | 'save' | null;
}
/** Initial state of a newly opened review tab. */
export declare const EMPTY_REVIEW: ReviewQueueState;
/** One review tab's drafts and records, retained until its occurrence closes. */
export declare class ReviewQueue {
    private readonly key;
    private closed;
    private state;
    private readonly listeners;
    private readonly keys;
    private nextKey;
    private readonly files;
    /** @param key - browser storage key including Session and tab identity. */
    constructor(key: string);
    /** Current queue snapshot, stable between edits and storage failures. */
    readonly getSnapshot: () => ReviewQueueState;
    /**
     * Clear this tab's records and refuse later completions from its outgoing requests.
     * @returns whether its browser storage was cleared; the in-memory state always closes.
     */
    close(): boolean;
    /** Summary subscribed by the surrounding diff; editing draft text does not invalidate its file rows. */
    readonly getStatus: () => string;
    /**
     * Read stable inline records for one path and review source.
     * @param path - repository-relative file path.
     * @param source - PR or local scope; older head commits remain available as outdated comments.
     * @returns records and edit availability, reusing the snapshot when these values are unchanged.
     */
    fileComments(path: string, source: ReviewSource): FileReviewState;
    /**
     * Retain an Agent reference at its original code location.
     * @param selection - reference already accepted by the main composer.
     * @returns whether the record was saved.
     */
    recordAgent(selection: ReviewSelection): boolean;
    /**
     * Retain a published comment and settle its outgoing write atomically in browser storage.
     * @param selection - published comment's frozen code location.
     * @param url - confirmed publication URL.
     * @returns whether the receipt and comment were saved.
     */
    published(selection: ReviewSelection, url: string): boolean;
    /**
     * Observe queue edits and storage failures.
     * @param listener - snapshot invalidation.
     * @returns unsubscribe.
     */
    readonly subscribe: (listener: () => void) => (() => void);
    /**
     * Save a frozen PR comment unless a write needs reconciliation.
     * @param selection - frozen PR comment.
     * @returns whether it was saved.
     */
    add(selection: ReviewSelection): boolean;
    /**
     * Edit or remove a pending comment without changing its captured lines.
     * @param index - comment position.
     * @param body - replacement text, or null to remove.
     * @returns whether saved.
     */
    edit(index: number, body: string | null): boolean;
    /**
     * Edit the currently pending occurrence addressed by an inline record.
     * @param key - browser-store identity from fileComments.
     * @param body - replacement text, or null to remove.
     * @returns whether the occurrence still exists and the edit was saved.
     */
    editThread(key: number, body: string | null): boolean;
    /**
     * Save the summary and decision for the pending review.
     * @param body - review summary.
     * @param event - review decision.
     * @returns whether saved.
     */
    summarize(body: string, event: ReviewQueueState['event']): boolean;
    /**
     * Persist the outgoing request before network dispatch.
     * @param request - exact write.
     * @returns whether dispatch may start.
     */
    begin(request: ForgeReviewRequest): boolean;
    /**
     * Clear the write after a known result or explicit reconciliation.
     * @param submitted - whether a batch review was published.
     * @param url - confirmed publication URL when retaining submitted comments.
     * @returns whether saved.
     */
    finish(submitted: boolean, url?: string): boolean;
    private keyOf;
    private save;
    private emit;
}
/**
 * Compare review identity while allowing records from an older PR head to remain visible.
 * @param left - recorded source.
 * @param right - displayed source.
 * @returns whether the sources name the same PR or local scope.
 */
export declare function sameReviewSource(left: ReviewSource, right: ReviewSource): boolean;
//# sourceMappingURL=review-queue.d.ts.map