/** Copy for the More menu rows: navigation actions, and Creator draft prompts per region. */
export declare const en: {
    readonly pinTooltip: "Pin to left sidebar";
    readonly pin: "Pin {name} to sidebar";
    readonly install: "Browse other plugins";
    readonly create: "Create your plugin";
    readonly 'createPrompt.sidebar': "Create a DSH plugin with a left sidebar entry.";
    readonly 'createPrompt.conversation': "Create a DSH conversation view plugin.";
    readonly 'createPrompt.rightbar': "Create a DSH plugin with a right sidebar entry.";
};
/** Chinese counterpart of the entry-customization dictionary. */
export declare const zh: Record<keyof typeof en, string>;
/** Japanese copy, checked against the English keys. */
export declare const ja: {
    pinTooltip: string;
    pin: string;
    install: string;
    create: string;
    'createPrompt.sidebar': string;
    'createPrompt.conversation': string;
    'createPrompt.rightbar': string;
};
/** Spanish dictionary, checked against the English keys. */
export declare const es: {
    pinTooltip: string;
    pin: string;
    install: string;
    create: string;
    'createPrompt.sidebar': string;
    'createPrompt.conversation': string;
    'createPrompt.rightbar': string;
};
/** French dictionary, checked against the English keys. */
export declare const fr: {
    pinTooltip: string;
    pin: string;
    install: string;
    create: string;
    'createPrompt.sidebar': string;
    'createPrompt.conversation': string;
    'createPrompt.rightbar': string;
};
/** German dictionary, checked against the English keys. */
export declare const de: {
    pinTooltip: string;
    pin: string;
    install: string;
    create: string;
    'createPrompt.sidebar': string;
    'createPrompt.conversation': string;
    'createPrompt.rightbar': string;
};
/** Russian dictionary, checked against the English keys. */
export declare const ru: {
    pinTooltip: string;
    pin: string;
    install: string;
    create: string;
    'createPrompt.sidebar': string;
    'createPrompt.conversation': string;
    'createPrompt.rightbar': string;
};
/** Portuguese dictionary, checked against the English keys. */
export declare const pt: {
    pinTooltip: string;
    pin: string;
    install: string;
    create: string;
    'createPrompt.sidebar': string;
    'createPrompt.conversation': string;
    'createPrompt.rightbar': string;
};
//# sourceMappingURL=locales.d.ts.map