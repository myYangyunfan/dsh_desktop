import type { Context } from '@deepseek-ai/cordis';
/** Register the experiment's skill without a system-prompt section.
 * @param ctx - Owning plugin context with skill and plugin registries.
 */
export declare function registerCreationSkill(ctx: Context): void;
//# sourceMappingURL=skill.d.ts.map