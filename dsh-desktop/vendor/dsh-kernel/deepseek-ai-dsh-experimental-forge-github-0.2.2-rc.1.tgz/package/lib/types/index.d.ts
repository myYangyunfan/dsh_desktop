/** Registers the GitHub provider of `ctx.forge`, which reads pull requests through the GitHub CLI on the host. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "forge-github";
export declare const inject: string[];
/** GitHub CLI executable, served hosts, and invocation limits. */
export interface Config {
    /** GitHub CLI executable name or absolute host path. */
    ghCommand?: string;
    /** Host names this provider serves; list GitHub Enterprise hosts explicitly. */
    hosts?: string[];
    /** Deadline in milliseconds for one `gh` invocation. */
    timeoutMs?: number;
    /** Maximum captured bytes per `gh` output stream and combined JSON bytes of one complete check read. */
    maxOutputBytes?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map