/** Native executable search, Windows system paths, and sandbox temporary paths retained in the OS environment. */
export declare const STARTUP_ENVIRONMENT_NAMES: ReadonlySet<string>;
/**
 * Clear inherited credentials while preserving native child-process startup paths.
 * With the native child process, preloaded node:process exports observe the replacement.
 * Isolated state objects only replace their own environment; they do not replace the native process.
 * @param state - Native child process in production, or isolated state in in-process tests.
 */
export declare function clearProgramEnvironment(state: {
    env: NodeJS.ProcessEnv;
}): void;
//# sourceMappingURL=environment.d.ts.map