/** Validated configuration for sidebar-backed Agent terminals and the user-terminal tools. */
import z from '@deepseek-ai/schemastery';
/** Public plugin configuration. */
export interface Config {
    /** Terminal registry type served by sidebar terminals. */
    backendType: string;
    /** Initial terminal width; an attached sidebar view resizes it to its panel. */
    cols: number;
    /** Initial terminal height; an attached sidebar view resizes it to its panel. */
    rows: number;
    /** Executable names tried among the discovered shells before the execution environment's default shell. */
    preferredShells: string[];
    /** Variables added to Agent terminal environments, such as pagers that would otherwise wait for input. */
    environment: Record<string, string>;
    /** Output silence that ends shell startup once the shell owns the foreground. */
    startupSilenceMs: number;
    /** Bound on shell startup, including the person's startup files. */
    startupTimeoutMs: number;
    /** Output silence after which a send checks whether the shell or a reading program waits for input. */
    promptSilenceMs: number;
    /** Minimum interval between foreground process inspections, each of which may start `ps` twice. */
    probeIntervalMs: number;
    /** Output silence that ends a send as `inferred_idle`. */
    idleSilenceMs: number;
    /** Bound on one send. */
    timeoutMs: number;
    /** Maximum UTF-8 bytes in one screen read, send output or startup screen. */
    maxReadBytes: number;
    /** Register `user_terminal_list` and `user_terminal_read`, whose screen text enters the Session log and model requests. */
    readUserTerminals: boolean;
}
/** Schemastery config exposed by the plugin. */
export declare const Config: z<Partial<Config>, Config>;
/**
 * Reject timing values that cannot produce the documented wait reasons.
 * @param config - Schemastery-resolved configuration.
 */
export declare function validateConfig(config: Config): void;
//# sourceMappingURL=config.d.ts.map