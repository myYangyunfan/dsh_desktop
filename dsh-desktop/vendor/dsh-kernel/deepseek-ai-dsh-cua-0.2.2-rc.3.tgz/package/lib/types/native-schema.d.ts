/** Build-time native admission metadata derived from the shared operation definitions. */
import { z } from 'zod';
import { Request } from './protocol.ts';
/**
 * Derive native request schemas and admission fields from the shared operation definitions.
 * @param platformFields Additional native protocol fields accepted by the provider.
 * @param privateOperations Additional provider-only request schemas.
 * @returns Native field and enum tables and the complete wire schema.
 */
export declare function nativeProtocol(platformFields?: Partial<Record<z.infer<typeof Request>['method'] | 'requestPermission' | 'openPermissionSettings', z.ZodObject>>, privateOperations?: readonly z.ZodObject[]): {
    fields: Map<string, Set<string>>;
    enums: Map<string, Map<string, Set<string>>>;
    json: string;
};
//# sourceMappingURL=native-schema.d.ts.map