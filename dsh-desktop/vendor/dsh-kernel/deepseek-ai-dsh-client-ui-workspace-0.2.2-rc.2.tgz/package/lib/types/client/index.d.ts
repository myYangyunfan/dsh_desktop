import type { Context } from '@deepseek-ai/cordis';
import type { WorkspaceId, WorkspaceSnapshot } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { RemoteEndpoint } from '@deepseek-ai/dsh-api-remote-access/client';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import { type WorkspaceKey } from './locales.ts';
export type { StartSessionOptions, UiWorkspace } from './navigation.ts';
export type { DirectoryFlowOwnerProps, DirectoryFlowSlotName, DirectoryPickingHooks, DirectoryPickingInjected, MenuOpenState, RowToast, SessionRenameTarget, SessionRowOwnerProps, UseMenuOpenState, WorkspaceBrowserInjected, SessionRowScheduleOwnerProps, WorkspaceBrowserProps, WorkspacePickerInjected, WorkspacePickerProps, } from './contract/slots.ts';
export type { WorkspaceKey } from './locales.ts';
/** Localized follow-up text for the existing archive notice. */
export interface ArchiveNotice {
    readonly text: string;
    readonly tone: 'success' | 'warning';
}
declare module '@deepseek-ai/cordis' {
    interface Events {
        /**
         * Replace the archive notice with a localized follow-up description.
         * @param sessionId - Session whose archive has succeeded.
         * @param next - fallback to the remaining notice providers.
         * @mode waterfall
         */
        'workspace/archive-notice'(sessionId: SessionId, next: () => Promise<ArchiveNotice | undefined>): Promise<ArchiveNotice | undefined>;
        /**
         * Replace the archive notice when an admitted background operation fails.
         * @param sessionId - Session whose successful archive remains in effect.
         * @param text - localized failure and recovery guidance.
         * @mode emit
         */
        'workspace/archive-followup-failed'(sessionId: SessionId, text: string): void;
        /**
         * Restore the plain archive notice when an announced follow-up ended without acting.
         * @param sessionId - Session whose successful archive remains in effect.
         * @mode emit
         */
        'workspace/archive-followup-settled'(sessionId: SessionId): void;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface GlobalStandardProps {
        /** Selector hook over the pure Workspace Controller snapshot. */
        useWorkspaces: SnapshotSelectorHook<WorkspaceSnapshot>;
        /** Whether the current Peer may call `action` on one Workspace resource. */
        useWorkspaceAccess: (workspaceId: WorkspaceId, action: RemoteEndpoint) => boolean;
    }
    interface LocaleNamespaceMap {
        /** The workspace browsing region and pick/create flow copy. */
        workspace: WorkspaceKey;
    }
}
declare module '@deepseek-ai/dsh-api-session-controller/client' {
    interface SessionReferenceSourceMap {
        workspaceOperation: unknown;
    }
}
/**
 * Required services (cordis fiber inject). The target slots are declared by
 * the ui-sidebar / ui-conversation applies, whose activation order relative
 * to this one is NOT constrained: dsh.client.inject edges are informational
 * (loading/prefetch metadata, never apply sequencing) and neither owner
 * provides a waitable service. apply therefore depends on each slot
 * declaration through `slots.inject()` instead of assuming order.
 */
export declare const inject: string[];
/**
 * Register the browser and picker once their slot declarations are on the
 * ledger. Inject factories return plain callbacks; data reads use the
 * framework's global hooks.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map