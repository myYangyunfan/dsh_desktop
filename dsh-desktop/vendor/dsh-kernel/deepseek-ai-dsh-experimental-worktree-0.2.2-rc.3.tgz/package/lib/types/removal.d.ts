/** Identity validation shared by restoration and removal, and the conservative inspection before a checkout is removed. */
import type { Context } from '@deepseek-ai/cordis';
import type { RestoreWorktreeRequest } from './types.ts';
/** Runs one Git command in the owner's confinement and reports its complete bounded output. */
export type GitRead = (directory: string, args: string[]) => Promise<{
    stdout: string;
    exitCode: number;
}>;
/**
 * Runs one Git command in the owner's confinement and passes each
 * NUL-terminated stdout field to `onField` without retaining the output;
 * false from `onField` ends the command. Resolves true when `onField` ended it.
 */
export type GitScan = (directory: string, args: string[], onField: (field: string) => boolean) => Promise<boolean>;
/** The confined Git runners inspection and removal use. */
export interface GitCommands {
    /** Commands whose output stays small, read whole. */
    readonly read: GitRead;
    /** Commands whose output grows with the repository or its worktrees, read as it arrives. */
    readonly scan: GitScan;
}
/** Resolved canonical locations of a recorded checkout that validation confirmed. */
export interface CheckoutIdentity {
    readonly root: Awaited<ReturnType<Context['fs']['resolve']>>;
    readonly target: Awaited<ReturnType<Context['fs']['resolve']>>;
}
/**
 * Confirm that a recorded checkout names a canonical directory inside the
 * configured pool of the source checkout it claims, and that the source is
 * still that repository's top level.
 * @param ctx - execution-world filesystem provider.
 * @param directory - configured relative worktree pool.
 * @param request - saved checkout identity.
 * @param run - bounded Git runner with the owner's policy.
 * @param signal - cancellation of the lookups.
 * @returns the resolved root and target, or null when any identity check fails.
 */
export declare function checkoutIdentity(ctx: Context, directory: string, request: RestoreWorktreeRequest, run: GitRead, signal: AbortSignal): Promise<CheckoutIdentity | null>;
/**
 * Find the registration of `target` among the source repository's worktrees.
 * The listing grows with the number of worktrees; it is streamed without an
 * output limit, and its entries are kept in memory while `target` is resolved.
 * @param ctx - execution-world filesystem provider.
 * @param request - saved checkout identity.
 * @param target - resolved checkout directory.
 * @param scan - streaming Git runner with the owner's policy.
 * @param signal - cancellation of the lookups.
 * @returns the porcelain fields of the matching entry, or undefined when none is registered.
 */
export declare function registration(ctx: Context, request: RestoreWorktreeRequest, target: CheckoutIdentity['target'], scan: GitScan, signal: AbortSignal): Promise<readonly string[] | undefined>;
/**
 * Inspect the checkout and, when eligible and still admitted after inspection,
 * remove it and its registration with a non-force `git worktree remove`. The
 * branch is never deleted; a rejection can leave a partial directory.
 * @param ctx - execution-world filesystem provider.
 * @param directory - configured relative worktree pool.
 * @param request - saved checkout identity.
 * @param git - confined Git runners with the owner's policy.
 * @param signal - cancellation before or during removal.
 * @param admit - synchronous final admission after inspection; false retains the checkout.
 * @returns true when removed; false when inspection or admission retains it; Git failures reject.
 */
export declare function removeCheckout(ctx: Context, directory: string, request: RestoreWorktreeRequest, git: GitCommands, signal: AbortSignal, admit: () => boolean): Promise<boolean>;
/**
 * Verify checkout identity and that `git status` reports no tracked changes or
 * untracked files; its output is read only up to the first entry. Ignored files
 * are not counted, nor are edits to skip-worktree or assume-unchanged files,
 * which `git status` hides; `git worktree remove` discards both. A checkout
 * whose administrative directory holds submodule repositories is ineligible,
 * as Git refuses to remove it; a committed embedded repository is not
 * inspected, so Git's refusal of that removal rejects.
 * @param ctx - execution-world filesystem provider.
 * @param directory - configured relative worktree pool.
 * @param request - saved checkout identity.
 * @param git - confined Git runners with the owner's policy.
 * @param signal - cancellation of inspection.
 * @returns false for an ineligible checkout; inspection failures reject.
 */
export declare function inspectRemoval(ctx: Context, directory: string, request: RestoreWorktreeRequest, git: GitCommands, signal: AbortSignal): Promise<boolean>;
//# sourceMappingURL=removal.d.ts.map