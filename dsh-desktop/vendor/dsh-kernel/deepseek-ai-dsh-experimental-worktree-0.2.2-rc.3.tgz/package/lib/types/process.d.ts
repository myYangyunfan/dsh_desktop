/** Cancellable commands under the calling Session's existing file policy, whose stdout is collected within a bound or streamed. */
import type { Context } from '@deepseek-ai/cordis';
import type { SandboxExecutionPolicy } from '@deepseek-ai/dsh-sandbox';
/** Resolved process resource limits owned by the worktree service. */
export interface ProcessConfig {
    /** Deadline for one command, including executable lookup and confinement. */
    timeoutMs: number;
    /** Termination grace period for each managed subprocess. */
    graceMs: number;
    /** Maximum captured bytes per output stream. */
    maxOutputBytes: number;
}
/**
 * Run an argv without a shell and await termination of its managed process range.
 * @param ctx - subprocess and sandbox providers in the same execution world.
 * @param config - complete process resource limits.
 * @param policy - unchanged calling Session policy.
 * @param cwd - canonical process working directory.
 * @param argv - executable followed by literal arguments.
 * @param signal - operation cancellation.
 * @param allowedExitCodes - command-specific successful statuses.
 * @param env - command-local environment overrides, applied after Git selector removal.
 * @returns complete bounded stdout and the exit code.
 */
export declare function runCommand(ctx: Context, config: ProcessConfig, policy: SandboxExecutionPolicy, cwd: string, argv: readonly [string, ...string[]], signal: AbortSignal, allowedExitCodes?: readonly number[], env?: NodeJS.ProcessEnv): Promise<{
    stdout: string;
    exitCode: number;
}>;
/**
 * Run an argv as {@link runCommand} does, but pass each NUL-terminated stdout
 * field to `onField` as it arrives instead of retaining the output, so the size
 * of stdout is unbounded and `maxOutputBytes` limits only stderr. An
 * unterminated remainder is ignored. A false return from `onField` terminates
 * the command, whose outcome is then not checked, even when the provider
 * rejects it for a launch cancelled before acknowledgement; otherwise only
 * status 0 succeeds.
 * @param ctx - subprocess and sandbox providers in the same execution world.
 * @param config - complete process resource limits.
 * @param policy - unchanged calling Session policy.
 * @param cwd - canonical process working directory.
 * @param argv - executable followed by literal arguments.
 * @param signal - operation cancellation.
 * @param onField - synchronous consumer of each field in order; false ends the command.
 * @returns true when `onField` ended the command, false when it exited successfully first.
 */
export declare function scanCommand(ctx: Context, config: ProcessConfig, policy: SandboxExecutionPolicy, cwd: string, argv: readonly [string, ...string[]], signal: AbortSignal, onField: (field: string) => boolean): Promise<boolean>;
//# sourceMappingURL=process.d.ts.map