/** Native directory flow using the local desktop bridge or the Host's OS chooser. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
/** Required services (cordis fiber inject): the slot registry, workspace UI service, and access. */
export declare const inject: string[];
/**
 * Client plugin body: while the current Peer may open the Host's directory
 * chooser, register the renderless native flow into all three directory-flow
 * holes through `slots.inject()` because the ui-workspace declarations may
 * activate later or be replaced.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map